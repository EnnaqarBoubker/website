@extends('layouts.front-master')

@section('content-main')
<div class="main" id="login_bg">
    <div id="login">
        <aside>
            <figure style="height:75px !important;" >
{{--                <a href="index.html"><img src="{{ asset('assets/frontend') }}/img/logoo.png" width="149" height="42" data-retina="true" alt=""></a>--}}
            </figure>
            @if( session()->has('error') )
                <div class="alert alert-danger">
                    {{ session()->get('error') }}
                </div>
            @endif
            <form method="POST" action="{{ route('login') }}">
                {{ csrf_field() }}

                <div class="form-group">
                    <span class="input {{ $errors->has('email') ? ' has-error' : '' }}">
                        <input id="email" type="email" class="input_field" name="email" value="{{ old('email') }}" required autofocus>
                        <label for="email" class="input_label"><span class="input__label-content">Entrer votre email</span></label>
                        @if ($errors->has('email'))
                            <span class="help-block">
                                <strong>{{ $errors->first('email') }}</strong>
                            </span>
                        @endif
                   </span>

                    <span class="input {{ $errors->has('password') ? ' has-error' : '' }}">
                        <input id="password" type="password" class="input_field" name="password" required>
                        <label for="password" class="input_label"><span class="input__label-content">Entrer votre mot de password</span></label>
                          @if ($errors->has('password'))
                            <span class="help-block">
                                <strong>{{ $errors->first('password') }}</strong>
                            </span>
                        @endif
                    </span>
                </div>

                <div class="form-group">
                        <div class="checkbox">
                            <label>
                                <input type="checkbox" name="remember" {{ old('remember') ? 'checked' : '' }}> Se souvenir de moi
                            </label>
                        </div>
                </div>

                <div class="form-group">
                        <button type="submit" class="btn btn-primary">
                            Se connecter
                        </button>

                    <br>
                    <a class="btn btn-link" href="{{ url('inscription') }}">
                        Vous ne possédez pas de compte? <br>Créer votre compte.
                    </a>

                    <a class="btn btn-link" href="#">
                        Mot de passe oublié ?
                    </a>
                </div>
            </form>
        </aside>
    </div>
    <!-- /login -->
</div>
@endsection
