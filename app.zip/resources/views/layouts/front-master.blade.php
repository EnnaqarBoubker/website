<!DOCTYPE html>
<html lang="{{ app()->getLocale() }}">
<head>

    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="La 1ère plateforme des coaches professionnels au Maroc">
    <meta name="author" content="Centre Mikdad">
    <title>Centre Mikdad | Acceuil</title>
    @yield("styles")
    <!-- Favicons-->
    <link rel="shortcut icon" href="{{ asset("assets/frontend") }}/img/favicon.ico" type="image/x-icon">
    <link rel="apple-touch-icon" type="image/x-icon" href="{{ asset("assets/frontend") }}/img/apple-touch-icon-57x57-precomposed.png">
    <link rel="apple-touch-icon" type="image/x-icon" sizes="72x72" href="{{ asset("assets/frontend") }}/img/apple-touch-icon-72x72-precomposed.png">
    <link rel="apple-touch-icon" type="image/x-icon" sizes="114x114" href="{{ asset("assets/frontend") }}/img/apple-touch-icon-114x114-precomposed.png">
    <link rel="apple-touch-icon" type="image/x-icon" sizes="144x144" href="{{ asset("assets/frontend") }}/img/apple-touch-icon-144x144-precomposed.png">

    <!-- BASE CSS -->
    <link href="{{ asset("assets/frontend") }}/css/bootstrap.min.css" rel="stylesheet">
    <link href="{{ asset("assets/frontend") }}/css/style.css" rel="stylesheet">
    <link href="{{ asset("assets/frontend") }}/css/vendors.css" rel="stylesheet">
    <link href="{{ asset("assets/frontend") }}/css/icon_fonts/css/all_icons.min.css" rel="stylesheet">

    <!-- SPECIFIC CSS -->
    <link href="{{ asset("assets/frontend") }}/layerslider/css/layerslider.css" rel="stylesheet">

    @yield("laststyles")
    <!-- YOUR CUSTOM CSS -->
    <link href="{{ asset("assets/frontend") }}/css/custom.css" rel="stylesheet">
    <link href="{{ asset("assets/frontend") }}/css/font-awesome.min.css" rel="stylesheet">
    <meta name="description" content="Centre Mikdad">

</head>

<body>

<div id="page">

<header class="header menu_2">
   <div id="preloader"><div data-loader="circle-side"></div></div><!-- /Preload -->
{{--    <div class="container text-center">--}}
{{--        <h4 style="color: white">Le site en construction </h4>--}}
{{--        <img src="{{ asset("assets/frontend") }}/img/construction.gif" height="100px" alt="Centre Mikdad">--}}
{{--    </div>--}}
   <div id="logo" style="margin-left: 25px" >
       <a href="{{ url("accueil") }} "><img src="{{ asset("assets/frontend") }}/img/logoo.png" width="55px" height="55px" data-retina="true" alt=""></a>
   </div>
   <ul id="top_menu">
{{--            <li><a href="#" class="login">Connexion</a></li>--}}
{{--       <li><a href="#0" class="search-overlay-menu-btn">Recherche</a></li>--}}
       @if(Auth::check())
           @php
               $user = Auth::user();
           @endphp
           @if( $user->role == 1)
               <li class=""><a href="{{ url("home") }}" class="btn_1 rounded">Mon Compte</a></li>
           @elseif( $user->role == 2)
               <li class=""><a href="{{ url("coach-admin") }}" class="btn_1 rounded">Mon Compte</a></li>
           @elseif( $user->role == 3)
               <li class=""><a href="{{ url("admin") }}" class="btn_1 rounded">Mon Compte</a></li>
           @endif
       @else
           <li class=""><a href="{{ url("login") }}" class="btn_1 rounded">Se connecter</a></li>
       @endif
   </ul>
   <!-- /top_menu -->
   <a href="#menu" class="btn_mobile">
       <div class="hamburger hamburger--spin" id="hamburger">
           <div class="hamburger-box">
               <div class="hamburger-inner"></div>
           </div>
       </div>
   </a>
   <nav id="menu" class="main-menu">

       <ul>
           <li><span><a href="{{ url("accueil") }} ">Accueil</a></span>
           </li>
           <li><span><a href="{{ url("a-propos") }} ">Qui somme nous!</a></span>
           </li>
           <li><span><a href="{{  url("liste-formations") }} ">Formations</a></span>
           </li>
{{--           <li><span><a href="{{  url("liste-coachs") }} ">Coachs</a></span>--}}
{{--           </li>--}}
           <li><span><a href="{{  url("liste-articles") }} ">Articles</a></span>
           </li>
           <li><span><a href="{{  url("contact") }} ">Contact</a></span></li>
       </ul>
   </nav>
   <!-- Search Menu -->
{{--   <div class="search-overlay-menu">--}}
{{--       <span class="search-overlay-close"><span class="closebt"><i class="ti-close"></i></span></span>--}}
{{--       <form role="search" id="searchform" method="get">--}}
{{--           <input value="" name="q" type="search" placeholder="Recherche..." />--}}
{{--           <button type="submit"><i class="icon_search"></i>--}}
{{--           </button>--}}
{{--       </form>--}}
{{--   </div>--}}
    <!-- End Search Menu -->
</header>
<!-- /header -->

@yield("content-main")
<!-- /main -->

<footer>
   <div class="container margin_120_95">
       <div class="row">
           <div class="col-lg-5 col-md-12 p-r-5">
               <p>
                   <!--						<img src="{{ asset("assets/frontend") }}/img/logo.png" width="149" height="42" data-retina="true" alt="">-->
               <h3 style="color: #fff">Centre Mikdad</h3>
               </p>
               <p><b>Centre MIKDAD</b> est le premier centre de coaching à Marrakech depuis 2011.<br>
                   Notre méthodologie de travail et de formation diffère grandement de l’ensemble des méthodologies sur les quelles le coaching est enseigné</p>
               <div class="follow_us">
                   <ul>
                       <li>Suivi nous sur</li>
                       <li><a target="_blank" href="https://web.facebook.com/mikdadcentre/?_rdc=1&_rdr"><i class="ti-facebook"></i></a></li>
                       <li><a target="_blank" href="https://www.instagram.com/coach_mikdad/"><i class="ti-instagram"></i></a></li>
{{--                       <li><a href="#0"><i class="ti-twitter-alt"></i></a></li>--}}
{{--                       <li><a href="#0"><i class="ti-linkedin"></i></a></li>--}}
                       <li><a target="_blank" href="https://youtube.com/channel/UCCQK1xsXqGPJMQI76U7x6rw"><i class="ti-youtube"></i></a></li>
                   </ul>
               </div>
           </div>
           <div class="col-lg-3 col-md-6 ml-lg-auto">
               <h5>Liens</h5>
               <ul class="links">
                   <li><a href="#0">Coach</a></li>
                   <li><a href="#0">About</a></li>
                   <!--						<li><a href="#0">Login</a></li>-->
                   <!--						<li><a href="#0">Register</a></li>-->
                   <!--						<li><a href="#0">News &amp; Events</a></li>-->
                   <li><a href="#0">Contacts</a></li>
               </ul>
           </div>
           <div class="col-lg-3 col-md-6">
               <h5>Contactez nous</h5>
               <ul class="contacts">
                   <li><a href="tel://212639365470"><i class="ti-mobile"></i> + 212 6 39 36 54 70</a></li>
                   <li><a href="mailto:contact@centremikdad.com"><i class="ti-email"></i> contact@centremikdad.com</a></li>
               </ul>
               <div id="newsletter">
                   <h6>Newsletter</h6>
                   <div id="message-newsletter"></div>
                   <form method="post" action="{{ asset("assets/frontend") }}/assets/newsletter.php" name="newsletter_form" id="newsletter_form">
                       <div class="form-group">
                           <input type="email" name="email_newsletter" id="email_newsletter" class="form-control" placeholder="Votre email">
                           <input type="submit" value="Envoyer" id="submit-newsletter">
                       </div>
                   </form>
               </div>
           </div>
       </div>
       <!--/row-->
       <hr>
       <div class="row">
           <div class="col-md-8">
               <ul id="additional_links">
                   <li><a href="#0">Terms and conditions</a></li>
                   <li><a href="#0">Privacy</a></li>
               </ul>
           </div>
           <div class="col-md-4">
               <div id="copy">© 2021 Centre Mikdad <p> créer par : <a href="https://communication.icf.ma/">icf.ma</a></p> </div>
           </div>
       </div>
   </div>
</footer>
<!--/footer-->
</div>
<!-- page -->

<!-- COMMON SCRIPTS -->
<script src="{{ asset("assets/frontend") }}/js/jquery-2.2.4.min.js"></script>
<script src="{{ asset("assets/frontend") }}/js/common_scripts.js"></script>
<script src="{{ asset("assets/frontend") }}/js/main.js"></script>
<script src="{{ asset("assets/frontend") }}/assets/validate.js"></script>

@yield("javascript")
<script>
    document.addEventListener('contextmenu', event => event.preventDefault());
</script>
</body>
</html>