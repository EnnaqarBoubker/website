@extends("layouts.front-master")

@section("content-main")
	<main>
		<section id="hero_in" class="courses">
			<div class="wrapper">
				<div class="container">
					<h1 class="fadeInUp"><span></span>Formation : {{ $formation->titre }}</h1>
				</div>
			</div>
		</section>
		<!--/hero_in-->

		<div class="bg_color_1">
			<nav class="secondary_nav sticky_horizontal">
				<div class="container">
					<ul class="clearfix">
						<li><a href="#description" class="active">Description</a></li>
						<li><a href="#lessons">Programme</a></li>
						<li><a href="#reviews">Commentaires</a></li>
					</ul>
				</div>
			</nav>
			<div class="container margin_60_35">
				<div class="row">
					<div class="col-lg-8">
						<section id="description">
							<img src="@if ($formation->image !="") {{ asset('assets/formations/'.$formation->image) }} @else {{ asset('assets/frontend/img/centre-mikdad.jpg') }} @endif "
									alt="Centre Mikdad {{ $formation->titre }} "
									width="100%">
							<h2 class="mt-3">Description</h2>
							<p>
								{{ str_replace("&nbsp;", " ", strip_tags($formation->description)) }}
							</p>
							<!-- /row -->
						</section>
						<!-- /section -->
						
						<section id="lessons">
							<div class="intro_title">
								<h2>Le programme</h2>

							</div>
							<div id="accordion_lessons" role="tablist" class="add_bottom_45">
								@php $count=1; @endphp

								@foreach( $formation->chapitres as $ch)
								<!-- /card -->
								<div class="card">
									<div class="card-header" role="tab" id="heading{{ $ch->id }}Two">
										<h5 class="mb-0">
											<a class="collapsed" data-toggle="collapse" href="#collapse{{ $ch->id }}Two" aria-expanded="@if($count ==1) true @else false @endif" aria-controls="collapse{{ $ch->id }}Two">
												<i class="indicator @if( $count === 1 ) ti-minus @else ti-plus @endif"></i>{{ $ch->titre }}
											</a>
										</h5>
									</div>
									<div id="collapse{{ $ch->id }}Two" class="collapse @if($count ==1) show @endif" role="tabpanel" aria-labelledby="heading{{ $ch->id }}Two" data-parent="#accordion_lessons">
										<div class="card-body">
											<div class="list_lessons">
												<ul>
													@foreach( $ch->courses as $cour)
														@if($cour->type_cours ==1)
															<li><a @if( ($demande !=null) && ( $demande->validation == 2)) href="{{ url("/whatch-video/".$cour->id) }}" class="video" @endif >{{ $cour->titre }}</a><span>@if(($demande !=null) && ($demande->validation == 2)) <i class="fa fa-unlock" title="vous êtes participer a cette formation"></i> @else <i class="fa fa-lock" title="Il faut cliquer sur participer a cette formation"></i> @endif </span></li>
														@else
															<li><a @if( ($demande !=null) && ( $demande->validation == 2)) href="{{ asset('assets/courses/'.$cour->pdf_url) }}" @endif download="" class="txt_doc">{{ $cour->titre }}</a><span><i class="icon_download"></i> PDF @if(($demande !=null) && ($demande->validation == 2)) <i class="fa fa-unlock" title="vous êtes participer a cette formation"></i> @else <i class="fa fa-lock" title="Il faut cliquer sur participer a cette formation"></i> @endif </span></li>
														@endif

													@endforeach
												</ul>
											</div>
										</div>
									</div>
								</div>
								@php $count++; @endphp

								@endforeach
								<!-- /card -->
							</div>
							<!-- /accordion -->
						</section>
						<!-- /section -->
						
						<section id="reviews">
                            <!-- The modal -->
                            <div class="modal fade" id="flipFlop" tabindex="-1" role="dialog" aria-labelledby="modalLabel" aria-hidden="true">
                                <div class="modal-dialog" role="document">
                                    <div class="modal-content">
                                        <div class="modal-header">
                                            <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                                <span aria-hidden="true">&times;</span>
                                            </button>
                                            <h4 class="modal-title" id="modalLabel">Modal Title</h4>
                                        </div>
                                        <div class="modal-body">
                                            Modal content...
                                        </div>
                                        <div class="modal-footer">
                                            <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                                        </div>
                                    </div>
                                </div>
                            </div>

							<h2>Commentaires</h2>

							<hr>

							<h6>En chargement....</h6>

						</section>
						<!-- /section -->
					</div>
					<!-- /col -->
					
					<aside class="col-lg-4" id="sidebar">
						<div class="box_detail">
							<figure>
								@if( $formation->video !="" && $formation->video !=null )
									<a href="{{ asset('assets/formations/'.$formation->video) }}" class="video"><i class="arrow_triangle-right"></i><img src="@if ($formation->image !="") {{ asset('assets/formations/'.$formation->image) }} @else {{ asset('assets/frontend/img/centre-mikdad.jpg') }} @endif " alt="Centre Mikdad {{ $formation->titre }} " class="img-fluid"><span>Afficher la présentation</span></a>
								@else
									<img src="@if ($formation->image !="") {{ asset('assets/formations/'.$formation->image) }} @else {{ asset('assets/frontend/img/centre-mikdad.jpg') }} @endif " alt="Centre Mikdad {{ $formation->titre }} " class="img-fluid">
								@endif

							</figure>
							<div class="price">
								Prix: <span class="original_price"> @if($formation->new_prix ==0) {{ $formation->prix }} Dhs @elseif($formation->new_prix >0)  <del> {{ $formation->prix }} Dhs</del> {{ $formation->new_prix }} Dhs @endif </span>
							</div>
							@if( $demande == null)
								<a href="{{ url( "participer-au-formation/".$formation->id."-".$formation->titre) }}" class="btn_1 full-width">Participer au formation</a>
							@else
								@if($demande->validation == 0)
									<a href="{{ url( "paiment-formation/".$formation->id."-".$formation->titre ) }}" class="btn_1 full-width">Passer au paiement</a>
								@elseif($demande->validation == 1)
									<a href="#lessons" class="btn_1 full-width">Validation En Attend</a>
								@else
									<a href="#lessons" class="btn_1 full-width">Suivez le cours</a>
								@endif
							@endif
							<a href="#" class="btn_1 full-width outline"><i class="icon_heart"></i> Ajouter au Favorit</a>
							<div id="list_feat">
								<h3>Ce qui est inclut</h3>
								<ul>
									<li><i class="icon_mobile"></i>Adaptatif au Mobile</li>
									<li><i class="icon_archive_alt"></i>Archive des leçons</li>
									<li><i class="icon_chat_alt"></i>Le chat avec le Coach</li>
									<li><i class="icon_document_alt"></i>Attestation de formation</li>
								</ul>
							</div>
						</div>
					</aside>
				</div>
				<!-- /row -->
			</div>
			<!-- /container -->
		</div>
		<!-- /bg_color_1 -->
	</main>
	<!--/main-->

@endsection
