<?php

namespace App\Http\Controllers;

use App\Categorie;
use App\Coach;
use App\User;
use Illuminate\Http\Request;
use Illuminate\Http\UploadedFile;
use File;
use App\Formation;
use Illuminate\Support\Facades\Auth;

class FormationController extends Controller
{

    public function __construct()
    {
        $this->middleware('auth');
    }

    public function index(){
//        $id_coach = Auth::user()->id;
       // dd($id_coach);
//      var_dump("ok");die;

        if (Auth::user()->role == 3){
            $listFormation = Formation::all();
        }else{
            $coach = Coach::select('*')->where('user_id', Auth::user()->id)->first();
            $listFormation = $coach->formations;
        }

//        $listFormation = Formation::all();

//         dd($listFormation);
        return view("backend.coach.formations.list-formations",array("formations"=> $listFormation));
    }

    public function show(){
        //return view("backend.coach.formations.create");

    }

    public function create(){
        $categories = Categorie::all();
        return view("backend.coach.formations.create",array("categories"=> $categories));
    }

    public function store(Request $request){


            $formation = new Formation();

            $formation->date = date("Y-m-d H:i:s");
            $formation->lieu = "";
            $formation->new_prix = 0;

            $formation->type = $request->input("type");
            $formation->categorie_id = $request->input("categorie_id");
            $formation->titre = $request->input("titre");
            $formation->prix = $request->input("prix");
            $formation->description = $request->input("description");
            $formation->status = $request->input("status");

            if ($request->input("date") !=null){
                $formation->date = $request->input("date");
            }

            if ($request->input("new_prix") !=null){
                $formation->new_prix = $request->input("new_prix");
            }

            if ($request->input("lieu") !=null){
                $formation->lieu = $request->input("lieu");
            }

            if ($request->input("coach_id") !=null){
                $formation->coach_id = $request->input("coach_id");
            }else {
                $coach = Coach::select('*')->where('user_id', Auth::user()->id)->first();
                $formation->coach_id = $coach->id;
            }

            $fileName = "";
            if ($request->hasFile('image')) {

                $file = $request->file('image');
//                $fileName = md5($file->getClientOriginalName() . time()) . "." . $file->getClientOriginalExtension();
                $fileName = "coach-maroc-".$formation->titre. "." . $file->getClientOriginalExtension();
                $file->move('./assets/formations/', $fileName);

            }
            $formation->image = $fileName;

            $fileNameVideo = "";
            if ($request->hasFile('video')) {

                $file = $request->file('video');
    //                $fileName = md5($file->getClientOriginalName() . time()) . "." . $file->getClientOriginalExtension();
                $fileNameVideo = "coach-maroc-".$formation->titre. "." . $file->getClientOriginalExtension();
                $file->move('./assets/formations/', $fileNameVideo);

            }
            $formation->video = $fileNameVideo;


        if($formation->save()){
            // echo message bien ajouter
//            return redirect('/admin/formations/')->with('success_register','La Formation a été bien ajouter !');
            session()->flash("success","La Formation a été bien ajouter !");
            return redirect('/coach-admin/formations');
        }else {
            // echo message error
//            return redirect('/coach-admin/formations/')->with('error_register','Erreur d\'ajouer le coach !');
            session()->flash("error","Erreur d\'ajouer le coach !");
            return redirect('/coach-admin/formations');
        }

    }

    public function edit($id){
        $formation = Formation::find($id);
        $categories = Categorie::all();
//        $this->authorize('update',$coach);
        return view("backend.coach.formations.edit",["formation" => $formation,"categories"=> $categories]);
    }

    public function update(Request $request,$id){

        $formation = Formation::find($id);

        $formation->date = date("Y-m-d H:i:s");
        $formation->lieu = "";
        $formation->new_prix = 0;

        $formation->type = $request->input("type");
        $formation->categorie_id = $request->input("categorie_id");
        $formation->titre = $request->input("titre");
        $formation->prix = $request->input("prix");
        $formation->description = $request->input("description");
        $formation->status = $request->input("status");

        if ($request->input("date") !=null){
            $formation->date = $request->input("date");
        }

        if ($request->input("new_prix") !=null){
            $formation->new_prix = $request->input("new_prix");
        }

        if ($request->input("lieu") !=null){
            $formation->lieu = $request->input("lieu");
        }

        if ($request->input("coach_id") !=null){
            $formation->id_coach = $request->input("coach_id");
        }else {
            $coach = Coach::select('*')->where('user_id', Auth::user()->id)->first();
            $formation->coach_id = $coach->id;
        }

        $fileName = $formation->image;
        if ($request->hasFile('image')) {
            $file = $request->file('image');
//                $fileName = md5($file->getClientOriginalName() . time()) . "." . $file->getClientOriginalExtension();
            $fileName = "coach-maroc-".$formation->titre. "." . $file->getClientOriginalExtension();
            $file->move('./assets/formations/', $fileName);
        }
        $formation->image = $fileName;

        $fileNameVideo = $formation->video;
        if ($request->hasFile('video')) {
            $file = $request->file('video');
            //                $fileName = md5($file->getClientOriginalName() . time()) . "." . $file->getClientOriginalExtension();
            $fileNameVideo = "coach-maroc-".$formation->titre. "." . $file->getClientOriginalExtension();
            $file->move('./assets/formations/', $fileNameVideo);
        }
        $formation->video = $fileNameVideo;


        if($formation->save()){
            // echo message bien ajouter
//            return redirect('/admin/formations/')->with('success_register','La Formation a été bien ajouter !');
            session()->flash("success","La Formation a été bien modifier !");
            return redirect('/coach-admin/formations');
        }else {
            // echo message error
//            return redirect('/coach-admin/formations/')->with('error_register','Erreur d\'ajouer le coach !');
            session()->flash("error","Erreur de modofier la formation !");
            return redirect('/coach-admin/formations');
        }
    }

    public function destroy(Request $request,$id){
        $formation = Formation::find($id);

        if($formation->delete()){
            // echo message bien supprimer
            session()->flash("success",'La Formation a été bien supprimer !');
            return redirect('/coach-admin/formations');

        }else {
            // echo message error
            session()->flash("success",'Erreur de supprimer la formation !');
            return redirect('/coach-admin/formations');
        }
    }
}
