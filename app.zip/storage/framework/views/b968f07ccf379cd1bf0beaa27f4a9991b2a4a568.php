<?php $__env->startSection("laststyles"); ?>
	<link href="<?php echo e(asset("assets/frontend")); ?>/css/blog.css" rel="stylesheet">
<?php $__env->stopSection(); ?>

<?php $__env->startSection("content-main"); ?>
	
	<main>
		<section id="hero_in" class="general">
			<div class="wrapper">
				<div class="container">
					<h1 class="fadeInUp"><span></span>Articles</h1>
				</div>
			</div>
		</section>
		<!--/hero_in-->

		<div class="container margin_60_35">
			<div class="row">
				<div class="col-lg-9">
					<?php $__currentLoopData = $articles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $obj): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
					<article class="blog wow fadeIn">
						<div class="row no-gutters">
							<div class="col-lg-7">
								<figure>
									<a href="<?php echo e(url("details-article/".$obj->id.'-'.$obj->titre)); ?>"><img src="<?php echo e(asset("assets/articles/". $obj->image)); ?>" alt="Centre Mikdad <?php echo e($obj->titre); ?>">
										<div class="preview"><span>Lire plus</span></div>
									</a>
								</figure>
							</div>
							<div class="col-lg-5">
								<div class="post_info">
									<small> <?php  setlocale( LC_TIME, 'French');  ?>
										<?php echo e(\Carbon\Carbon::parse( $obj->date )->formatLocalized ('%d %B %Y')); ?>

									</small>
									<h3><a href="#blog-post"><?php echo e($obj->titre); ?></a></h3>
									<p>
										<?php 
											$coach = getCoachById($obj->coach_id);
											$d =  str_replace("&nbsp;", " ", strip_tags($obj->description));
                                               if (strlen($d) > 300) {
                                                   // truncate string

                                                   $descCut = substr($d, 0, 300);
                                                   $endPoint = strrpos($descCut, ' ');

                                                   //if the string doesn't contain any space then it will cut without word basis.
                                                   $d = $endPoint? substr($descCut, 0, $endPoint) : substr($descCut, 0);
                                                   $d .= '...';
                                               }
										 ?>
										<?php echo e($d); ?>

									</p>
									<ul>
										<li>
											<div class="thumb"><img src="<?php echo e(asset('assets/coachs/'. $coach->photo)); ?>" alt="Centre Mikdad <?php echo e($coach->prenom); ?> <?php echo e($coach->nom); ?>"></div>
											<a href="<?php echo e(url("coach/".$coach->id.'-'.$coach->nom.'-'.$coach->prenom)); ?>"><?php echo e($coach->prenom); ?> <?php echo e($coach->nom); ?></a>
										</li>
										<li> </li>
									</ul>
								</div>
							</div>
						</div>
					</article>
					<!-- /article -->
					<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
					<nav aria-label="...">
						<ul class="pagination pagination-sm">
							<li class="page-item disabled">
								<a class="page-link" href="#" tabindex="-1">Précedent</a>
							</li>
							<li class="page-item"><a class="page-link" href="#">1</a></li>
							<li class="page-item"><a class="page-link" href="#">2</a></li>
							<li class="page-item"><a class="page-link" href="#">3</a></li>
							<li class="page-item">
								<a class="page-link" href="#">Suivant</a>
							</li>
						</ul>
					</nav>
					<!-- /pagination -->
				</div>
				<!-- /col -->

				<aside class="col-lg-3">

					<div class="widget">
						<div class="widget-title">
							<h4>Articles récents</h4>
						</div>
						<ul class="comments-list">
							<?php $__currentLoopData = $lastarticles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $art): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
								<li>
									<div class="alignleft">
										<a href="<?php echo e(url("details-article/".$art->id.'-'.$art->titre)); ?>"><img src="<?php echo e(asset("assets/articles/". $art->image)); ?>" alt="Centre Mikdad <?php echo e($art->titre); ?>"></a>
									</div>
									<small><?php echo e(date('d.m.Y', strtotime($art->date))); ?></small>
									<h3><a href="<?php echo e(url("details-article/".$art->id.'-'.$art->titre)); ?>" title="<?php echo e($art->titre); ?>"><?php echo e($art->titre); ?></a></h3>
								</li>
							<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
						</ul>
					</div>
					<!-- /widget -->
					<div class="widget">
						<div class="widget-title">

						</div>
						<ul class="cats">




						</ul>
					</div>
					<!-- /widget -->
					<div class="widget">
						<div class="widget-title">

						</div>
						<div class="tags">






						</div>
					</div>
					<!-- /widget -->
				</aside>
				<!-- /aside -->
			</div>
			<!-- /row -->
		</div>
		<!-- /container -->
	</main>
<?php $__env->stopSection(); ?>
<!-- /main -->

<?php echo $__env->make("layouts.front-master", array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>