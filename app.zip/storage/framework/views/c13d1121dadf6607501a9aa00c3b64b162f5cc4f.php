<?php $__env->startSection("content-main"); ?>
	<main>
		<section id="hero_in" class="courses">
			<div class="wrapper">
				<div class="container">
					<h1 class="fadeInUp"><span></span>Formation : <?php echo e($formation->titre); ?></h1>
				</div>
			</div>
		</section>
		<!--/hero_in-->

		<div class="bg_color_1">
			<nav class="secondary_nav sticky_horizontal">
				<div class="container">
					<ul class="clearfix">
						<li><a href="#description" class="active">Description</a></li>
						<li><a href="#lessons">Programme</a></li>
						<li><a href="#reviews">Commentaires</a></li>
					</ul>
				</div>
			</nav>
			<div class="container margin_60_35">
				<div class="row">
					<div class="col-lg-8">
						<section id="description">
							<img src="<?php if($formation->image !=""): ?> <?php echo e(asset('assets/formations/'.$formation->image)); ?> <?php else: ?> <?php echo e(asset('assets/frontend/img/centre-mikdad.jpg')); ?> <?php endif; ?> "
									alt="Centre Mikdad <?php echo e($formation->titre); ?> "
									width="100%">
							<h2 class="mt-3">Description</h2>
							<p>
								<?php echo e(str_replace("&nbsp;", " ", strip_tags($formation->description))); ?>

							</p>
							<!-- /row -->
						</section>
						<!-- /section -->
						
						<section id="lessons">
							<div class="intro_title">
								<h2>Le programme</h2>

							</div>
							<div id="accordion_lessons" role="tablist" class="add_bottom_45">
								<?php  $count=1;  ?>

								<?php $__currentLoopData = $formation->chapitres; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ch): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
								<!-- /card -->
								<div class="card">
									<div class="card-header" role="tab" id="heading<?php echo e($ch->id); ?>Two">
										<h5 class="mb-0">
											<a class="collapsed" data-toggle="collapse" href="#collapse<?php echo e($ch->id); ?>Two" aria-expanded="<?php if($count ==1): ?> true <?php else: ?> false <?php endif; ?>" aria-controls="collapse<?php echo e($ch->id); ?>Two">
												<i class="indicator <?php if( $count === 1 ): ?> ti-minus <?php else: ?> ti-plus <?php endif; ?>"></i><?php echo e($ch->titre); ?>

											</a>
										</h5>
									</div>
									<div id="collapse<?php echo e($ch->id); ?>Two" class="collapse <?php if($count ==1): ?> show <?php endif; ?>" role="tabpanel" aria-labelledby="heading<?php echo e($ch->id); ?>Two" data-parent="#accordion_lessons">
										<div class="card-body">
											<div class="list_lessons">
												<ul>
													<?php $__currentLoopData = $ch->courses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cour): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
														<?php if($cour->type_cours ==1): ?>
															<li><a <?php if( ($demande !=null) && ( $demande->validation == 2)): ?> href="<?php echo e(url("/whatch-video/".$cour->id)); ?>" class="video" <?php endif; ?> ><?php echo e($cour->titre); ?></a><span><?php if(($demande !=null) && ($demande->validation == 2)): ?> <i class="fa fa-unlock" title="vous êtes participer a cette formation"></i> <?php else: ?> <i class="fa fa-lock" title="Il faut cliquer sur participer a cette formation"></i> <?php endif; ?> </span></li>
														<?php else: ?>
															<li><a <?php if( ($demande !=null) && ( $demande->validation == 2)): ?> href="<?php echo e(asset('assets/courses/'.$cour->pdf_url)); ?>" <?php endif; ?> download="" class="txt_doc"><?php echo e($cour->titre); ?></a><span><i class="icon_download"></i> PDF <?php if(($demande !=null) && ($demande->validation == 2)): ?> <i class="fa fa-unlock" title="vous êtes participer a cette formation"></i> <?php else: ?> <i class="fa fa-lock" title="Il faut cliquer sur participer a cette formation"></i> <?php endif; ?> </span></li>
														<?php endif; ?>

													<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
												</ul>
											</div>
										</div>
									</div>
								</div>
								<?php  $count++;  ?>

								<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
								<!-- /card -->
							</div>
							<!-- /accordion -->
						</section>
						<!-- /section -->
						
						<section id="reviews">
                            <!-- The modal -->
                            <div class="modal fade" id="flipFlop" tabindex="-1" role="dialog" aria-labelledby="modalLabel" aria-hidden="true">
                                <div class="modal-dialog" role="document">
                                    <div class="modal-content">
                                        <div class="modal-header">
                                            <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                                <span aria-hidden="true">&times;</span>
                                            </button>
                                            <h4 class="modal-title" id="modalLabel">Modal Title</h4>
                                        </div>
                                        <div class="modal-body">
                                            Modal content...
                                        </div>
                                        <div class="modal-footer">
                                            <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                                        </div>
                                    </div>
                                </div>
                            </div>

							<h2>Commentaires</h2>

							<hr>

							<h6>En chargement....</h6>

						</section>
						<!-- /section -->
					</div>
					<!-- /col -->
					
					<aside class="col-lg-4" id="sidebar">
						<div class="box_detail">
							<figure>
								<?php if( $formation->video !="" && $formation->video !=null ): ?>
									<a href="<?php echo e(asset('assets/formations/'.$formation->video)); ?>" class="video"><i class="arrow_triangle-right"></i><img src="<?php if($formation->image !=""): ?> <?php echo e(asset('assets/formations/'.$formation->image)); ?> <?php else: ?> <?php echo e(asset('assets/frontend/img/centre-mikdad.jpg')); ?> <?php endif; ?> " alt="Centre Mikdad <?php echo e($formation->titre); ?> " class="img-fluid"><span>Afficher la présentation</span></a>
								<?php else: ?>
									<img src="<?php if($formation->image !=""): ?> <?php echo e(asset('assets/formations/'.$formation->image)); ?> <?php else: ?> <?php echo e(asset('assets/frontend/img/centre-mikdad.jpg')); ?> <?php endif; ?> " alt="Centre Mikdad <?php echo e($formation->titre); ?> " class="img-fluid">
								<?php endif; ?>

							</figure>
							<div class="price">
								Prix: <span class="original_price"> <?php if($formation->new_prix ==0): ?> <?php echo e($formation->prix); ?> Dhs <?php elseif($formation->new_prix >0): ?>  <del> <?php echo e($formation->prix); ?> Dhs</del> <?php echo e($formation->new_prix); ?> Dhs <?php endif; ?> </span>
							</div>
							<?php if( $demande == null): ?>
								<a href="<?php echo e(url( "participer-au-formation/".$formation->id."-".$formation->titre)); ?>" class="btn_1 full-width">Participer au formation</a>
							<?php else: ?>
								<?php if($demande->validation == 0): ?>
									<a href="<?php echo e(url( "paiment-formation/".$formation->id."-".$formation->titre )); ?>" class="btn_1 full-width">Passer au paiement</a>
								<?php elseif($demande->validation == 1): ?>
									<a href="#lessons" class="btn_1 full-width">Validation En Attend</a>
								<?php else: ?>
									<a href="#lessons" class="btn_1 full-width">Suivez le cours</a>
								<?php endif; ?>
							<?php endif; ?>
							<a href="#" class="btn_1 full-width outline"><i class="icon_heart"></i> Ajouter au Favorit</a>
							<div id="list_feat">
								<h3>Ce qui est inclut</h3>
								<ul>
									<li><i class="icon_mobile"></i>Adaptatif au Mobile</li>
									<li><i class="icon_archive_alt"></i>Archive des leçons</li>
									<li><i class="icon_chat_alt"></i>Le chat avec le Coach</li>
									<li><i class="icon_document_alt"></i>Attestation de formation</li>
								</ul>
							</div>
						</div>
					</aside>
				</div>
				<!-- /row -->
			</div>
			<!-- /container -->
		</div>
		<!-- /bg_color_1 -->
	</main>
	<!--/main-->

<?php $__env->stopSection(); ?>

<?php echo $__env->make("layouts.front-master", array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>