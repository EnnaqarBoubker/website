<?php $__env->startSection("content-main"); ?>
	<main>
		<section id="hero_in" class="courses">
			<div class="wrapper">
				<div class="container">
					<h1 class="fadeInUp"><span></span>Liste des formations</h1>
				</div>
			</div>
		</section>
		<!--/hero_in-->
		<div class="filters_listing sticky_horizontal">
			<div class="container">
				<ul class="clearfix">
					<li>
						<div class="switch-field">
							<input type="radio" id="all" name="listing_filter" value="all" checked>
							<label for="all">Tout</label>
							<input type="radio" id="popular" name="listing_filter" value="popular">
							<label for="popular">Populaires</label>
							<input type="radio" id="latest" name="listing_filter" value="latest">
							<label for="latest">Dérniers</label>
						</div>
					</li>

					<li>
						<select name="orderby" class="selectbox">
							<option value=""> Filtrer par </option>
							<?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
								<option value="<?php echo e($cat->id); ?>"><?php echo e($cat->nom); ?></option>
							<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
						</select>
					</li>
				</ul>
			</div>
			<!-- /container -->
		</div>
		<!-- /filters -->

		<div class="container margin_60_35">
			<div class="row">
				<?php $__currentLoopData = $formations; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $obj): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
					<div class="col-xl-4 col-lg-6 col-md-6">
						<div class="box_grid wow">
							<figure>
								<a href="<?php echo e(url('details-formation/'.$obj->id.'-'.$obj->titre)); ?>"><img src="<?php if($obj->image !=""): ?> <?php echo e(asset('assets/formations/'.$obj->image)); ?> <?php else: ?> <?php echo e(asset('assets/frontend/img/centre-mikdad.jpg')); ?> <?php endif; ?>" class="img-fluid" alt="Centre Mikdad <?php echo e($obj->titre); ?>"></a>
								<div class="price">
									<?php if($obj->new_prix > 0): ?>
										<del> <?php echo e($obj->prix); ?> Dhs</del>  <?php echo e($obj->new_prix); ?> Dhs
									<?php else: ?>
										<?php echo e($obj->prix); ?> Dhs
									<?php endif; ?>
								</div>
								<div class="preview"><a href="<?php echo e(url('details-formation/'.$obj->id.'-'.$obj->titre)); ?>"><span>Afficher les détails</span></a></div>
							</figure>
							<div class="wrapper">
								<small>Categorie: <?php echo e(getNameCategorieById( $obj->categorie_id )); ?> </small>
								<h3><?php echo e($obj->titre); ?></h3>
								<p>
									<?php 
										$desc =  str_replace("&nbsp;", " ", strip_tags($obj->description));
                                           if (strlen($desc) > 90) {

                                               // truncate string
                                               $descCut = substr($desc, 0, 90);
                                               $endPoint = strrpos($descCut, ' ');

                                               //if the string doesn't contain any space then it will cut without word basis.
                                               $desc = $endPoint? substr($descCut, 0, $endPoint) : substr($descCut, 0);
                                               $desc .= '...';
                                           }
									 ?>
									<?php echo e($desc); ?>

								</p>
							</div>
							<ul>
								<li><i class="icon_easel"></i></li>
								<li><a href="<?php echo e(url( 'details-formation/'.$obj->id.'-'.$obj->titre )); ?>">Afficher les détails</a></li>
							</ul>
						</div>
					</div>
					<!-- /box_grid -->
				<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
			</div>
			<!-- /row -->

		</div>
		<!-- /container -->
		<div class="bg_color_1">
			<div class="container margin_60_35">
				<div class="row">
					<div class="col-md-4">
						<a href="#0" class="boxed_list">
							<i class="pe-7s-help2"></i>
							<h4>Besoin d'aide? Nous contacter</h4>
							<p>contacez nous pour plus d'informations. enovyer un email ou contacter nous par whatsapp 212629485433
							</p>
						</a>
					</div>
					<div class="col-md-4">
						<a href="#0" class="boxed_list">
							<i class="pe-7s-cash"></i>
							<h4>Paiement</h4>
							<p>Vous pouvez passer votre paiement par virement bancaire ou par verssement WafaCash ou Paypal.</p>
						</a>
					</div>
					<div class="col-md-4">
						<a href="#0" class="boxed_list">
							<i class="pe-7s-note2"></i>
							<h4>Qualité de formations</h4>
							<p>Nous proposant les plus excellent formations, présenté par les professionnels coachs au maroc</p>
						</a>
					</div>
				</div>
				<!-- /row -->
			</div>
			<!-- /container -->
		</div>
		<!-- /bg_color_1 -->
	</main>
<?php $__env->stopSection(); ?>
<?php echo $__env->make("layouts.front-master", array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>