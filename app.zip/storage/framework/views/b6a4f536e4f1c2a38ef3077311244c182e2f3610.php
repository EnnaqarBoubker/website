<?php $__env->startSection("laststyles"); ?>
	<link href="<?php echo e(asset("assets/frontend")); ?>/css/blog.css" rel="stylesheet">
<?php $__env->stopSection(); ?>

<?php $__env->startSection("content-main"); ?>
	<main>
		<section id="hero_in" class="general">
			<div class="wrapper">
				<div class="container">
					<h1 class="fadeInUp"><span></span><?php echo e($article->titre); ?></h1>
				</div>
			</div>
		</section>
		<!--/hero_in-->

		<div class="container margin_60_35">
			<div class="row">
				<div class="col-lg-9">
					<div class="bloglist singlepost" dir="rtl">
						<p><img alt="<?php echo e($article->titre); ?> Centre Mikdad" class="img-fluid" src="<?php echo e(asset('assets/articles/'.$article->image)); ?>" width="100%"></p>
						<h1><?php echo e($article->titre); ?></h1>
						<div class="postmeta">
							<ul>
								<li><a href="#"><i class="icon_clock_alt"></i> <?php echo e(date('d.m.Y', strtotime($article->date))); ?></a></li>
								<li><a href="#"><i class="icon_pencil-edit"></i> Coach: <?php echo e($article->coach->prenom); ?> <?php echo e($article->coach->nom); ?></a></li>

							</ul>
						</div>
						<!-- /post meta -->
						<div class="post-content">

							<div class="">
								<p><?php echo e(str_replace("&nbsp;", " ", strip_tags($article->description))); ?> </p>
							</div>
						</div>
						<!-- /post -->
					</div>
					<!-- /single-post -->

					<div id="comments">
						<h5>Comments</h5>
						<h6>chargement....</h6>
					</div>

					<hr>



















				</div>
				<!-- /col -->

				<aside class="col-lg-3">
					<div class="widget">
						<form>
							<div class="form-group">
								<input type="text" name="search" id="search" class="form-control" placeholder="rechercher...">
							</div>
							<button type="submit" id="submit" class="btn_1 rounded"> Eecherche</button>
						</form>
					</div>
					<!-- /widget -->
					<div class="widget">
						<div class="widget-title">
							<h4>Articles récents</h4>
						</div>
						<ul class="comments-list">
							<?php $__currentLoopData = $lastarticles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $art): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
								<li>
									<div class="alignleft">
										<a href="<?php echo e(url("details-article/".$art->id.'-'.$art->titre)); ?>"><img src="<?php echo e(asset("assets/articles/". $art->image)); ?>" alt="Centre Mikdad <?php echo e($art->titre); ?>"></a>
									</div>
									<small><?php echo e(date('d.m.Y', strtotime($art->date))); ?></small>
									<h3><a href="<?php echo e(url("details-article/".$art->id.'-'.$art->titre)); ?>" title="<?php echo e($art->titre); ?>"><?php echo e($art->titre); ?></a></h3>
								</li>
							<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
						</ul>
					</div>
					<!-- /widget -->
					<div class="widget">
						<div class="widget-title">
							
						</div>
						<ul class="cats">
							
							
							
							
						</ul>
					</div>
					<!-- /widget -->
					<div class="widget">
						<div class="widget-title">
							
						</div>
						<div class="tags">
							
							
							
							
							
							
						</div>
					</div>
					<!-- /widget -->
				</aside>
				<!-- /aside -->
			</div>
			<!-- /row -->
		</div>
		<!-- /container -->
	</main>
	<!--/main-->
<?php $__env->stopSection(); ?>
	

<?php echo $__env->make("layouts.front-master", array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>