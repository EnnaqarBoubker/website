<?php $__env->startSection("content-main"); ?>
	<main>
		<section id="hero_in" class="general">
			<div class="wrapper">
				<div class="container">
					<h1 class="fadeInUp"><span></span>à propos</h1>
				</div>
			</div>
		</section>
		<!--/hero_in-->

		<div class="bg_color_1">
			<div class="container margin_60_35">
				<div class="main_title_2">
					<span><em></em></span>
					<h2>Qui somme nous !</h2>
					<p>Centre Mikdad est le premier centre de coaching professionnels à Marrakech.</p>
				</div>
				<div class="row justify-content-between">
					<div class="col-lg-6 wow" data-wow-offset="150">
						<figure class="block-reveal">
							<div class="block-horizzontal"></div>
							<img src="<?php echo e(asset("assets/frontend/img/centre-mikdad.jpg")); ?>" class="img-fluid" alt="centre mikdad logo">
						</figure>
					</div>
					<div class="col-lg-5">
						<p>Notre méthodologie de travail et de formation diffère grandement de l’ensemble des méthodologies sur les quelles le coaching est enseigné.

						</p><p>	Nous n’enseignons pas des informations et des connaissances indépendantes, mais nous enseignons également la relation entre toutes ces informations avec la formule analytique adéquate qui permet d’avoir une boite à outils complète, sans oublier de se référer aux preuves pour chaque information et rassembler tout cela dans un un modèle de formation unique.
							 
						</p><p>	La plupart des méthodologies enseignent des informations sur un domaine spécifique,  contrairement à ce qui peut être utilisé dans tous les domaines et aussi les atouts qui te permettent d’extraire d’une information un ensemble d’autres encore, chose qui n’est pas disponible dans la majorité des centres qui fournissent des informations limitées.

						</p><p>	Dans notre approche, nous cherchons à convertir des connaissances difficiles et complexes en information simples et les relier à la réalité, car ce que nous proposons et basé sur la méthode expérimentale scientifique.</p>
					</div>
				</div>
				<!--/row-->
			</div>
			<!--/container-->
		</div>
		<!--/bg_color_1-->











































































		<!-- /container -->

		<div class="bg_color_1">
			<div class="container margin_60_35">
				<div class="main_title_2">
					<span><em></em></span>
					<h2>COACH MOHAMED MIKDAD</h2>
					<p>Expert en formation et conseil, Mohamed MIKDAD a formé plus de 700 professionnels du life coach au Maroc  et à l’etranger.</p>
				</div>
				<div class="row">
					<div class="col-lg-6 wow" data-wow-offset="150">
						<figure class="block-reveal">
							<div class="block-horizzontal"></div>
							<img src="<?php echo e(asset("assets/frontend/img/coach-mohamed-mikdad.jpg")); ?>" class="img-fluid" alt="centre mikdad logo">
						</figure>
					</div>
					<div class="col-lg-5">
						<p class=" text-justify"> La plupart d’entre eux ont ouvert leurs propores bureaux de coaching, et  certains d’autres travaillent avec le coach MIKDAD dans ses bureaux.</p>
						<p class=" text-justify"> Le formateur <b>Mohamed MIKDAD</b> est connu pour son énergie positive, sa passion pour la communication et ses performances émouvantes auxquelles de nombreux bénéficiaires assistent .</p>
						<p class=" text-justify"> <b>MIKDAD</b> est un formateur expert , un conférencier et un consultant en radio et télévision.</p>
						<p class=" text-justify"> La chose qui le motive avant tout, c’est reconnecter les personnes et les entreprises avec leurs leadership et de développer des stratégies de performance.</p>
						<p class=" text-justify"> Le <b>coach Mohamed Mikdad</b> a formé de nombreuses personnalités influentes dans le domaine des affaires et de la politique? Ainsi que dans le domaine du sport à travers des sessions de formation et des escortes individuelles.</p>
						<p class=" text-justify"> Il dirige un groupe d’entreprises prospères et détient un grand nombre d’actions dans différentes entreprises.</p>
						<p class=" text-justify"> Il accompagne également de nombreux propriétaires de petites et moyennes entreprises afin de les développer et atteindre leurs objectifs.</p>
						<p class=" text-justify"> Son rêve est que toute personne découvre ses capacités intérieurs et que nous sommes des gens normaux certe, capable de réaliser des choses extraordinaires, grâce à l’apprentissage et à la formation.</p>
					</div>
				</div>
				<!--/row-->
			</div>
			<!--/container-->
		</div>
		<!--/bg_color_1-->

	</main>
<?php $__env->stopSection(); ?>
<!-- /main -->

<?php echo $__env->make("layouts.front-master", array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>