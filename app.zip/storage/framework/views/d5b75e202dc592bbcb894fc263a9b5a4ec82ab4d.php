<?php $__env->startSection("content-main"); ?>
	<main>

		<!-- Slider -->
		<div id="full-slider-wrapper">
			<div id="layerslider" style="width:100%;height:750px;">
				<!-- first slide -->
				<div class="ls-slide" data-ls="slidedelay: 5000; transition2d:85;">
					<img src="<?php echo e(asset("assets/frontend")); ?>/img/3.jpg" class="ls-bg" alt="Slide background">
					<h3 class="ls-l slide_typo" style="top: 47%; left: 50%;font-size: 43px;text-align: center;line-height: 1" data-ls="offsetxin:0;durationin:2000;delayin:1000;easingin:easeOutElastic;rotatexin:90;transformoriginin:50% bottom 0;offsetxout:0;rotatexout:90;transformoriginout:50% bottom 0;">Le 1<sup>er</sup> centre des coaches<br>
						professionnels au Maroc</h3>
					<p class="ls-l slide_typo_2" style="top:55%; left:50%;" data-ls="durationin:2000;delayin:1000;easingin:easeOutElastic;">
						Formations & Consultations
					</p>
					<a class="ls-l btn_1 rounded" style="top:65%; left:50%;font-size: 17px; text-align: center; white-space: nowrap;" data-ls="durationin:2000;delayin:1400;easingin:easeOutElastic;" href='<?php echo e(url("inscription")); ?>'> Créer un compte</a>
				</div>
				<!-- second slide -->
				<div class="ls-slide" data-ls="slidedelay:5000; transition2d:103;">
					<img src="<?php echo e(asset("assets/frontend")); ?>/img/1.jpg" class="ls-bg" alt="Slide background">
					<h3 class="ls-l slide_typo" style="top: 47%; left: 50%;font-size: 43px;text-align: center;line-height: 1" data-ls="offsetxin:0;durationin:2000;delayin:1000;easingin:easeOutElastic;rotatexin:90;transformoriginin:50% bottom 0;offsetxout:0;rotatexout:90;transformoriginout:50% bottom 0;">Le 1<sup>er</sup> centre des coaches<br>
						professionnels au Maroc</h3>
					<p class="ls-l slide_typo_2" style="top:55%; left:50%;" data-ls="durationin:2000;delayin:1000;easingin:easeOutElastic;">
						Formations & Consultations
					</p>
					<a class="ls-l btn_1 rounded" style="top:65%; left:50%;font-size: 17px; text-align: center; white-space: nowrap;" data-ls="durationin:2000;delayin:1400;easingin:easeOutElastic;" href='<?php echo e(url("inscription")); ?>'> Créer un compte</a>
				</div>
				<!-- first slide -->
				<div class="ls-slide" data-ls="slidedelay: 5000; transition2d:85;">
					<img src="<?php echo e(asset("assets/frontend")); ?>/img/2.jpg" class="ls-bg" alt="Slide background">
					<h3 class="ls-l slide_typo" style="top: 47%; left: 50%;font-size: 43px;text-align: center;line-height: 1" data-ls="offsetxin:0;durationin:2000;delayin:1000;easingin:easeOutElastic;rotatexin:90;transformoriginin:50% bottom 0;offsetxout:0;rotatexout:90;transformoriginout:50% bottom 0;">Le 1<sup>er</sup> centre des coaches<br>
						professionnels au Maroc</h3>
					<p class="ls-l slide_typo_2" style="top:55%; left:50%;" data-ls="durationin:2000;delayin:1000;easingin:easeOutElastic;">
						Formations & Consultations
					</p>
					<a class="ls-l btn_1 rounded" style="top:65%; left:50%;font-size: 17px; text-align: center; white-space: nowrap;" data-ls="durationin:2000;delayin:1400;easingin:easeOutElastic;" href='<?php echo e(url("inscription")); ?>'> Créer un compte</a>
				</div>
			</div>
		</div>
		<!-- End layerslider -->

		<div class="features clearfix">
			<div class="container">
				<ul>
					<li><i class="pe-7s-study"></i>
						<h4>Des formations professionnelles</h4><span>Vous souhaitez vous reconvertir ou acquérir des compétences pros ?</span>
					</li>
					<li><i class="pe-7s-user"></i>
						<h4>Des Coachs experts</h4><span>Vous accompagner pour réussir.</span>
					</li>
					<li><i class="pe-7s-target"></i>
						<h4>Support thécnique</h4><span>Vous accompagner et vous aider 24h/24h.</span>
					</li>
				</ul>
			</div>
		</div>
		<!-- /features -->


		<div class="container margin_30_95">
			<div class="main_title_2">
				<span><em></em></span>
				<h2>Catégories des formations</h2>
				<p>Découvrez les catégories et trouvez la formation que vous souhaitez</p>
			</div>
			<div class="row">

				<?php if( count( $categories) > 0 ): ?>

					<?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $categorie): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
					<div class="col-lg-4 col-md-6 wow" data-wow-offset="150">
					<a href="<?php echo e(url('liste-formations/'.$categorie->id.'-'.$categorie->nom)); ?>" class="grid_item">
						<figure class="block-reveal">
							<div class="block-horizzontal"></div>
							<img src="<?php echo e(asset("assets/categories/".$categorie->image)); ?>" class="img-fluid" alt="Centre Mikdad <?php echo e($categorie->nom); ?>">
							<div class="info">
								<small><i class="ti-layers"></i> <?php  echo '('. getNbrFormationByCat( $categorie->id ) .')'   ?>  Formations</small>
								<h3> <?php echo e($categorie->nom); ?> </h3>
							</div>
						</figure>
					</a>
				</div>
				<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
				<?php else: ?>
					<h4>Aucune catégorie</h4>
				<?php endif; ?>
				<!-- /grid_item -->
			</div>
			<!-- /row -->
		</div>
		<!-- /container -->

		<div class="container-fluid ">
			<div class="main_title_2">
				<span><em></em></span>
				<h2>Formations populaires</h2>
				<p>Centre Mikdad vous propose ses top formations</p>
			</div>
			<div id="reccomended_1" class="owl-carousel owl-theme">

				<?php if( count( $formations) > 0): ?>
					<?php $__currentLoopData = $formations; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $obj): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
					<div class="item">
						<div class="box_grid">
							<figure>
								<a href="<?php echo e(url( 'details-formation/'.$obj->id.'-'.$obj->titre )); ?>">
									<div class="preview"><span>Afficher les détails</span></div><img src="<?php if($obj->image !=""): ?> <?php echo e(asset('assets/formations/'.$obj->image)); ?> <?php else: ?> <?php echo e(asset('assets/frontend/img/centre-mikdad.jpg')); ?> <?php endif; ?>" class="img-fluid" alt="Centre Mikdad <?php echo e($obj->titre); ?>"></a>
								<div class="price">
									<?php if($obj->new_prix > 0): ?>
										<del> <?php echo e($obj->prix); ?> Dhs</del>  <?php echo e($obj->new_prix); ?> Dhs
									<?php else: ?>
										<?php echo e($obj->prix); ?> Dhs
									<?php endif; ?>
								</div>
							</figure>
							<div class="wrapper">

								<small>Categorie:<?php if( existe_categorie($obj->categorie_id )): ?> <?php echo e($obj->categorie->nom); ?> <?php else: ?> Aucune catégorie <?php endif; ?> </small>

								<h3><?php echo e($obj->titre); ?></h3>
								<p>
									<?php 
										$desc =  str_replace("&nbsp;", " ", strip_tags($obj->description));
                                           if (strlen($desc) > 90) {

                                               // truncate string
                                               $descCut = substr($desc, 0, 90);
                                               $endPoint = strrpos($descCut, ' ');

                                               //if the string doesn't contain any space then it will cut without word basis.
                                               $desc = $endPoint? substr($descCut, 0, $endPoint) : substr($descCut, 0);
                                               $desc .= '...';
                                           }
									 ?>
									<?php echo e($desc); ?>

								</p>
							</div>
							<ul>
								<li><i class="icon_easel"></i></li>
								<li><a href="<?php echo e(url( 'details-formation/'.$obj->id.'-'.$obj->titre)); ?> ">Afficher les détails</a></li>
							</ul>
						</div>
					</div>
					<!-- /item -->
				<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
				<?php else: ?>
					<h4>Aucune Formation</h4>
				<?php endif; ?>
			</div>
			<!-- /carousel -->
			<div class="container">
				<p class="btn_home_align"><a href="<?php echo e(url('liste-formations')); ?>" class="btn_1 rounded">Afficher tout les formations</a></p>
			</div>
			<!-- /container -->
			<hr>
		</div>
		<!-- /container -->

		<div class="bg_color_1">
			<div class="container margin_120_95">
				<div class="main_title_2">
					<span><em></em></span>
					<h2>Articles et Evènements</h2>
					<p>Découvrez les derniers articles</p>
				</div>
				<div class="row">
					<?php $__currentLoopData = $articles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $article): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
						<div class="col-lg-6">
							<a class="box_news" href="<?php echo e(url("details-article/".$article->id.'-'.$article->titre)); ?>">
								<figure><img src="<?php echo e(asset('assets/articles/'.$article->image)); ?>" alt="Centre Mikdad <?php echo e($article->titre); ?>">
									<?php 
										setlocale( LC_TIME, 'French');
									 ?>
									<figcaption><strong><?php echo e(\Carbon\Carbon::parse($article->date)->format('d')); ?></strong><?php echo e(\Carbon\Carbon::parse($article->date)->formatLocalized('%B')); ?></figcaption>
								</figure>
								<ul>
								<li>Coach: <?php echo e($article->coach->prenom); ?> <?php echo e($article->coach->nom); ?></li>
									<li>
										<?php echo e(date('d.m.Y', strtotime($article->date))); ?>

									</li>
								</ul>
								<h4><?php echo e($article->titre); ?></h4>
								<p>
									<?php 
										$d =  str_replace("&nbsp;", " ", strip_tags( $article->description));
                                           if (strlen($d) > 101) {

                                               // truncate string
                                               $descCut = substr($d, 0, 101);
                                               $endPoint = strrpos($descCut, ' ');

                                               //if the string doesn't contain any space then it will cut without word basis.
                                               $d = $endPoint? substr($descCut, 0, $endPoint) : substr($descCut, 0);
                                               $d .= '...';
                                           }
									 ?>
									<?php echo e($d); ?>

								</p>

							</a>
						</div>

						<!-- /box_news -->
					<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

				</div>
				<!-- /row -->
				<p class="btn_home_align"><a href="<?php echo e(url("liste-articles")); ?>" class="btn_1 rounded">Plus d'articles</a></p>
			</div>
			<!-- /container -->
		</div>
		<!-- /bg_color_1 -->

		<div class="call_section" style="display: none">
			<div class="container clearfix">
				<div class="col-lg-5 col-md-6 float-right wow" data-wow-offset="250">
					<div class="block-reveal">
						<div class="block-vertical"></div>
						<div class="box_1">
							<h3>Enjoy a great students community</h3>
							<p>Ius cu tamquam persequeris, eu veniam apeirian platonem qui, id aliquip voluptatibus pri. Ei mea primis ornatus disputationi. Menandri erroribus cu per, duo solet congue ut. </p>
							<a href="#0" class="btn_1 rounded">Read more</a>
						</div>
					</div>
				</div>
			</div>
		</div>
		<!--/call_section-->
	</main>
<?php $__env->stopSection(); ?>
	<!-- /main -->

<?php $__env->startSection("javascript"); ?>
	<!-- SPECIFIC SCRIPTS -->
	<script src="<?php echo e(asset("assets/frontend")); ?>/layerslider/js/greensock.js"></script>
	<script src="<?php echo e(asset("assets/frontend")); ?>/layerslider/js/layerslider.transitions.js"></script>
	<script src="<?php echo e(asset("assets/frontend")); ?>/layerslider/js/layerslider.kreaturamedia.jquery.js"></script>
	<script type="text/javascript">
		'use strict';
		$('#layerslider').layerSlider({
			autoStart: true,
			navButtons: false,
			navStartStop: false,
			showCircleTimer: false,
			responsive: true,
			responsiveUnder: 1280,
			layersContainer: 1200,
			skinsPath: 'layerslider/skins/'
				// Please make sure that you didn't forget to add a comma to the line endings
				// except the last line!
		});
	</script>
<?php $__env->stopSection(); ?>


<?php echo $__env->make("layouts.front-master", array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>