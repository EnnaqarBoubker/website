<?php $__env->startSection("content"); ?>
    <!-- /Navigation-->
    <div class="content-wrapper">
        <class="container-fluid">
        <!-- Breadcrumbs-->
        <ol class="breadcrumb">
            <li class="breadcrumb-item">
                <a href="#">Dashboard</a>
            </li>
            <li class="breadcrumb-item active">Modifier une catégorie</li>
        </ol>
        <form method="post" action="<?php echo e(url("admin/categories/".$categorie->id)); ?>">
            <input type="hidden" name="_method" value="PUT">
            <?php echo e(csrf_field()); ?>

            <div class="box_general padding_bottom">
                <div class="header_box version_2">
                    <h2><i class="fa fa-file"></i>Veuillez s'il vous plaît remplir les informations suivantes</h2>
                </div>
                <!-- /row-->
                <div class="row">
                    <div class="col-md-6">
                        <div class="form-group">
                            <label>Nom du Catégorie <span class="required">*</span></label>
                            <input required type="text" value="<?php echo e($categorie->nom); ?>" placeholder="Tappez le nom du catégorie ici..." class="form-control"  name="nom">
                        </div>
                    </div>
                    <div class="col-md-6">
                        <div class="form-group">
                            <label>Type de Formation <span class="required">*</span></label>
                            <select required name="status" class="form-control" id="status">
                                <option <?php if( $categorie->status ==  1): ?> selected <?php endif; ?>  value="1">Afficher</option>
                                <option <?php if( $categorie->status ==  0): ?> selected <?php endif; ?> value="0">Non Aficher</option>
                            </select>
                        </div>
                    </div>
                </div>
                <!-- /row-->
                <div class="row">
                    <p class="col-md-12 text-center"><input type="submit" class="btn_1 medium" value="Enregistrer"></p>
                </div>
            </div>
            <!-- /box_general-->


        </form>
    </div>
    <!-- /.container-fluid-->
    </div>
    <!-- /.container-wrapper-->
<?php $__env->stopSection(); ?>
<?php echo $__env->make("layouts.admin-master", array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>