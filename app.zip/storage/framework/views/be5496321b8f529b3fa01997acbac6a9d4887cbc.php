<?php $__env->startSection("content"); ?>

    <!-- /Navigation-->
    <div class="content-wrapper">
        <div class="container-fluid">
        
        
        
        
        
        
        
        
        
        
        
        <!-- Breadcrumbs-->
            <ol class="breadcrumb">
                <li class="breadcrumb-item">
                    <a href="#">Dashboard</a>
                </li>
                <li class="breadcrumb-item active">Ajouter un Coach</li>
            </ol>
            <form method="post" action="<?php echo e(url("admin/coachs/".$coach->id )); ?>" enctype="multipart/form-data" >
                <input type="hidden" name="_method" value="PUT">
                <?php echo e(csrf_field()); ?>


                <div class="box_general padding_bottom">
                    <div class="header_box version_2">
                        <h2><i class="fa fa-user"></i> Détails Profil </h2>
                    </div>
                    <div class="row">
                        <div class="col-md-4">
                            <div class="col-md-12">
                                <div class="form-group text-center">
                                    <label class="col-12">Votre photo</label>
                                    <?php if($coach->photo !=""): ?>
                                        <img src="<?php echo e(asset( 'storage/'.$coach->photo)); ?>" alt="" width="54%">
                                    <?php else: ?>
                                        <img src="<?php echo e(asset('assets/backend/img/avatar1.jpg')); ?>" alt="" width="54%">
                                    <?php endif; ?>
                                        <input type="file" class="form-control mt-3" name="photo">
                                </div>
                            </div>
                            <div class="col-md-12">
                                <div class="row">
                                    <div class="col-md-12">
                                        <div class="form-group">
                                            <label>Mot de passe</label>
                                            <input type="password" name="password" class="form-control" placeholder="Votre mot de passe">
                                        </div>
                                    </div>
                                    <div class="col-md-12">
                                        <div class="form-group">
                                            <label>Confirmer le mot de passe</label>
                                            <input type="password" name="repassword" class="form-control" placeholder="Re tappez le mot de passe">
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-8 add_top_30">
                            <div class="row">
                                <div class="col-md-6">
                                    <div class="form-group">
                                        <label>Nom</label>
                                        <input type="text" value="<?php echo e($coach->nom); ?>" class="form-control" name="nom" placeholder="Votre nom">
                                    </div>
                                </div>
                                <div class="col-md-6">
                                    <div class="form-group">
                                        <label>Prénom</label>
                                        <input type="text" value="<?php echo e($coach->prenom); ?>" name="prenom" class="form-control" placeholder="Votre prénom">
                                    </div>
                                </div>
                            </div>
                            <!-- /row-->
                            <div class="row">
                                <div class="col-md-6">
                                    <div class="form-group">
                                        <label>Téléphone</label>
                                        <input type="text" name="tel" value="<?php echo e($coach->tel); ?>" class="form-control" placeholder="Votre téléphone">
                                    </div>
                                </div>
                                <div class="col-md-6">
                                    <div class="form-group">
                                        <label>Email</label>
                                        <input type="email"  value="<?php echo e($coach->user->email); ?>" name="email" class="form-control" placeholder="Votre email">
                                    </div>
                                </div>
                            </div>
                            <!-- /row-->
                            <div class="row">
                                <div class="col-md-12">
                                    <div class="form-group">
                                        <label>Informations personnelles</label>
                                        <textarea style="height:100px;" name="info_pers"  class="form-control" placeholder="Votre Informations personnelles"><?php echo e($coach->info_pers); ?></textarea>
                                    </div>
                                </div>
                            </div>
                            <!-- /row-->
                            <div class="row">
                                <div class="col-md-12">
                                    <div class="form-group">
                                        <label>Spécialités <a href="#0" data-toggle="tooltip" data-placement="top" title="Separated by commas"><i class="fa fa-fw fa-question-circle"></i></a></label>
                                        <input type="text" name="specialities"  value="<?php echo e($coach->specialities); ?>" class="form-control" placeholder="Ex: informatique, développement...">
                                    </div>
                                </div>
                            </div>
                            <!-- /row-->
                        </div>
                    </div>
                </div>

                <!-- /box_general-->

                <div class="box_general padding_bottom">
                    <div class="header_box version_2">
                        <h2><i class="fa fa-share-alt"></i>Réseaux sociaux</h2>
                    </div>
                    <div class="row">
                        <div class="col-md-6">
                            <div class="form-group">
                                <label>Facebook</label>
                                <input type="text" name="url_fb"  value="<?php echo e($coach->url_fb); ?>" class="form-control" placeholder="Coller/tappez votre lien ici...">
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="form-group">
                                <label>Instagram</label>
                                <input type="text" name="url_inst"  value="<?php echo e($coach->url_inst); ?>" class="form-control" placeholder="Coller/tappez votre lien ici...">
                            </div>
                        </div>

                    </div>
                    <!-- /row-->
                    <div class="row">
                        <div class="col-md-12">
                            <div class="form-group">
                                <label>Youtube</label>
                                <input type="text" name="url_you"  value="<?php echo e($coach->url_you); ?>" class="form-control" placeholder="Coller/tappez votre lien ici...">
                            </div>
                        </div>
                    </div>

                    <!-- /row-->
                    <div class="row">
                        <div class="col-md-6">
                            <div class="form-group">
                                <label>Linkdin</label>
                                <input type="text" name="url_link" value="<?php echo e($coach->url_link); ?>" class="form-control" placeholder="Coller/tappez votre lien ici...">
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="form-group">
                                <label>Twitter</label>
                                <input type="text" name="url_tw"  value="<?php echo e($coach->url_tw); ?>" class="form-control" placeholder="Coller/tappez votre lien ici...">
                            </div>
                        </div>
                    </div>
                    <!-- /row-->

                </div>
                <!-- /box_general-->

                <div class="box_general padding_bottom">
                    <div class="header_box version_2">
                        <h2><i class="fa fa-file-text"></i>Diplômes</h2>
                    </div>
                    <div class="row">
                        <div class="col-md-12">
                            <div class="form-group">
                                <textarea rows="3" name="diplomes" class="form-control" placeholder="Expliquer ici"><?php echo e($coach->diplomes); ?></textarea>
                            </div>
                        </div>
                    </div>
                    <!-- /row-->
                </div>

                <div class="box_general padding_bottom">
                    <div class="header_box version_2">
                        <h2><i class="fa fa-star"></i>Autres Informations professionnels</h2>
                    </div>
                    <div class="row">
                        <div class="col-md-12">
                            <div class="form-group">
                                <label>Adresse Professionnel</label>
                                <textarea rows="2" name="adresse" class="form-control" placeholder="Tappez votre adresse professionnel ici"><?php echo e($coach->adresse); ?></textarea>
                            </div>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-md-4">
                            <div class="form-group">
                                <label>WhatsApp</label>
                                <input type="text" name="whatsapp" value="<?php echo e($coach->whatsapp); ?>" class="form-control" placeholder="Whatsapp : 2126xxxxxxxx">
                            </div>
                        </div>
                        <div class="col-md-4">
                            <div class="form-group">
                                <label>Téléphone Fix</label>
                                <input type="text" name="fixe" value="<?php echo e($coach->fixe); ?>" class="form-control" placeholder="Tél fix : 2125xxxxxxxx">
                            </div>
                        </div>
                        <div class="col-md-4">
                            <div class="form-group">
                                <label>Fax</label>
                                <input type="text" name="fax"  value="<?php echo e($coach->fax); ?>"  class="form-control" placeholder="Fax : 2125xxxxxxxx">
                            </div>
                        </div>
                    </div>
                    <!-- /row-->
                    <div class="row">
                        <div class="col-md-4">

                        </div>
                        <div class="col-md-4">
                            <div class="form-group">
                                <label>Statut</label>
                                <select name="status" id="status" class="form-control">
                                    <option <?php if($coach->status == 1): ?> selected <?php endif; ?> value="1"> Actif </option>
                                    <option <?php if($coach->status == 0): ?> selected <?php endif; ?> value="0"> Non Actif </option>
                                </select>
                            </div>
                        </div>
                        <div class="col-md-4">

                        </div>
                    </div>
                    <!-- /row-->
                </div>

                <!-- /box_general-->

                <p><input type="submit" class="btn_1 medium" value="Enregistrer"></p>

            </form>
        </div>
        <!-- /.container-fluid-->
    </div>
    <!-- /.container-wrapper-->
<?php $__env->stopSection(); ?>
<?php echo $__env->make("layouts.admin-master", array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>