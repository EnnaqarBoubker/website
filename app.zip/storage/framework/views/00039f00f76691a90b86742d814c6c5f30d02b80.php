<?php $__env->startSection('content-main'); ?>
<div class="main" id="login_bg">
    <div id="login">
        <aside>
            <figure style="height:75px !important;" >

            </figure>
            <?php if( session()->has('error') ): ?>
                <div class="alert alert-danger">
                    <?php echo e(session()->get('error')); ?>

                </div>
            <?php endif; ?>
            <form method="POST" action="<?php echo e(route('login')); ?>">
                <?php echo e(csrf_field()); ?>


                <div class="form-group">
                    <span class="input <?php echo e($errors->has('email') ? ' has-error' : ''); ?>">
                        <input id="email" type="email" class="input_field" name="email" value="<?php echo e(old('email')); ?>" required autofocus>
                        <label for="email" class="input_label"><span class="input__label-content">Entrer votre email</span></label>
                        <?php if($errors->has('email')): ?>
                            <span class="help-block">
                                <strong><?php echo e($errors->first('email')); ?></strong>
                            </span>
                        <?php endif; ?>
                   </span>

                    <span class="input <?php echo e($errors->has('password') ? ' has-error' : ''); ?>">
                        <input id="password" type="password" class="input_field" name="password" required>
                        <label for="password" class="input_label"><span class="input__label-content">Entrer votre mot de password</span></label>
                          <?php if($errors->has('password')): ?>
                            <span class="help-block">
                                <strong><?php echo e($errors->first('password')); ?></strong>
                            </span>
                        <?php endif; ?>
                    </span>
                </div>

                <div class="form-group">
                        <div class="checkbox">
                            <label>
                                <input type="checkbox" name="remember" <?php echo e(old('remember') ? 'checked' : ''); ?>> Se souvenir de moi
                            </label>
                        </div>
                </div>

                <div class="form-group">
                        <button type="submit" class="btn btn-primary">
                            Se connecter
                        </button>

                    <br>
                    <a class="btn btn-link" href="<?php echo e(url('inscription')); ?>">
                        Vous ne possédez pas de compte? <br>Créer votre compte.
                    </a>

                    <a class="btn btn-link" href="#">
                        Mot de passe oublié ?
                    </a>
                </div>
            </form>
        </aside>
    </div>
    <!-- /login -->
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.front-master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>