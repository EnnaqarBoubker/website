

<?php $__env->startSection("addheaderscript"); ?>

    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('assets/backend/css/form-upload.css')); ?>">

<?php $__env->stopSection(); ?>

<?php $__env->startSection("content"); ?>

    <!-- /Navigation-->
    <div class="content-wrapper">
        <div class="container-fluid">

            <!-- Breadcrumbs-->
            <ol class="breadcrumb">
                <li class="breadcrumb-item">
                    <a href=" <?php echo e(url('coach-admin')); ?> ">Dashboard</a>
                </li>
                <li class="breadcrumb-item active">Ajouter un cours</li>
            </ol>
            <form method="post" id="imageupload" action=" <?php echo e(url('coach-admin/formations-courses/'.$cours->id)); ?> " enctype="multipart/form-data" >
                <input type="hidden" name="_method" value="PUT">
                <?php echo e(csrf_field()); ?>

                <div class="box_general padding_bottom">
                    <div class="header_box version_2">
                        <h2><i class="fa fa-file"></i>Veuillez s'il vous plaît remplir les informations suivantes</h2>
                    </div>


                    <div class="row">

                        <div class="col-md-8">
                            <div class="form-group <?php if($errors->get('titre')): ?> has-error <?php endif; ?> ">
                                <label>Titre du cours <span class="required">*</span></label>
                                <input type="text" value="<?php echo e($cours->titre); ?>" placeholder="Tappez le titre du cours ici..." class="form-control"  required name="titre">
                                <?php if($errors->get('titre')): ?>
                                    <?php $__currentLoopData = $errors->get('titre'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $message): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <li class="required">
                                            <?php echo e($message); ?>

                                        </li>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <?php endif; ?>
                            </div>
                        </div>
                        <div class="col-md-4">
                            <label>Choisissez le Type du cours <span class="required">*</span></label>
                            <div class="form-group radio_input">
                                <label><input type="radio" value="1" <?php if($cours->type_cours == 1): ?> checked <?php endif; ?> style="width: 25px; height: 22px" required name="type_cours" class="icheck"><strong> Vidéo</strong></label>
                                <label><input type="radio" value="2" <?php if($cours->type_cours == 2): ?> checked <?php endif; ?> style="width: 25px; height: 22px" required name="type_cours" class="icheck"><strong> Fichier(PDF/WORD/IMAGE)</strong></label>
                            </div>
                        </div>
                    </div>

                    <div class="box_general padding_bottom">
                        <div class="header_box version_2">
                            <h2><i class="fa fa-video-camera"></i>Videos/Fichier</h2>
                        </div>
                        <div class="row">
                            <div class="col-md-6">
                                <label>Choisissez le Type d'upload <span class="required">*</span></label>
                                <div class="form-group radio_input">
                                    <label><input type="radio" id="type_tr" value="1" style="width: 25px; height: 22px" checked required name="type_upload" class="icheck"><strong> Transfert </strong></label>
                                    <label><input type="radio" id="type_up" value="2" style="width: 25px; height: 22px" required name="type_upload" class="icheck"><strong> Téléchargement</strong></label>
                                </div>
                            </div>
                            <div class="col-md-6">
                                <h6>Tappez le nom du vidéo</h6>
                                <input type="text" id="video_name" value="<?php echo e($cours->video_url); ?>" class="form-control" placeholder="exemple : centre-mikdak-video-testenom.mp4" name="video_name">
                            </div>
                        </div>
                        <hr>
                        <div class="row">
                            <div class="col-md-6">
                                <h6>Cours sous forme du vidéo (Max : 128 Mo)</h6>
                                <table id="pricing-list-container" style="width:100%;">
                                    <tbody><tr class="pricing-list-item">
                                        <td>
                                            <div class="row">
                                                <div class="col-md-12">
                                                    <div class="form-group">
                                                        <input type="file" id="video" name="video_url" class="form-control" placeholder="Video title">
                                                    </div>
                                                </div>
                                            </div>
                                        </td>
                                    </tr>
                                    </tbody></table>
                            </div>
                            <div class="col-md-6">
                                <h6>Cours sous forme du PDF/WORD/IMAGE (Max : 128 Mo)</h6>
                                <table id="pricing-list-container2" style="width:100%;">
                                    <tbody><tr class="pricing-list-item">
                                        <td>
                                            <div class="row">
                                                <div class="col-md-12">
                                                    <div class="form-group">
                                                        <input type="file" id="pdf" name="pdf_url" class="form-control" placeholder="Fichier title">
                                                    </div>
                                                </div>
                                            </div>
                                        </td>
                                    </tr>
                                    </tbody></table>
                            </div>
                        </div>
                        <!-- /row-->
                    </div>
                    <div class="row">
                        <div class="col-md-12 text-center">
                            <h5>Choisissez le(s) chapitre(s) sur lesquels vous souhaitez que cette leçon apparaisse</h5>
                        </div>
                        <div class="col-md-12">
                            <?php $__currentLoopData = $formations; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $obj): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <div class="header_box version_2">
                                    <h4 class="bg-light py-3 px-4">Formation : <?php echo e($obj->titre); ?></h4>
                                </div>
                                <div class="row">

                                        <?php $__currentLoopData = $obj->chapitres; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ch): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <div class="col-md-4">
                                                <div class="custom-control custom-checkbox">
                                                    <input style="width: 22px; height: 25px;"  <?php if(test_chours_inchapitre_ByIdcrs_and_Idchp($cours->id,$ch->id)): ?> checked  <?php endif; ?> type="checkbox" id="customCheckbox<?php echo e($obj->id); ?>_<?php echo e($ch->id); ?>" name="chapitres[]" value="<?php echo e($ch->id); ?>">
                                                    <label for="customCheckbox<?php echo e($obj->id); ?>_<?php echo e($ch->id); ?>" class="custom-control-label ml-2"> <?php echo e($ch->titre); ?> </label>
                                                </div>
                                            </div>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
                    </div>
                    <hr>
                    <div class="row">
                        <div class="col-md-3"></div>
                        <div class="col-md-6">
                            <div class="form-group">
                                <label>Disponibilité sur le Site <span class="required">*</span></label>
                                <select name="status" class="form-control" id="status" required>
                                    <option value="1"  <?php if($cours->type_cours == 1): ?> checked <?php endif; ?> > Afficher</option>
                                    <option value="0"  <?php if($cours->type_cours == 0): ?> checked <?php endif; ?> > Non Afficher</option>
                                </select>
                            </div>
                        </div>
                        <div class="col-md-3"></div>
                    </div>
                    <!-- /row-->
                    <div class="row">
                        <div class="col-md-12">
                            <div id="progressbr-container" style="display:none;">
                                <div  id="progress-bar-status-show">	</div>

                            </div>
                        </div>
                        <div class="col-md-12">
                            <div class="text-center">
                                <div id="loader" style="display:none;">
                                    <img  src="<?php echo e(asset ('assets/backend/img/LoaderIcon.gif')); ?>" />
                                </div>
                            </div>
                        </div>

                        <p class="col-md-12 text-center"><input type="submit" class="btn_1 medium" value="Modifier Le Cours"></p>

                        <div class="form-group">
                            <div id="toshow" style="visibility:hidden;"></div>
                        </div>
                    </div>
                </div>
                <!-- /box_general-->
            </form>
        </div>
        <!-- /.container-fluid-->
    </div>
    <!-- /.container-wrapper-->
<?php $__env->stopSection(); ?>

<?php $__env->startSection("addfooterscript"); ?>

    <script src="<?php echo e(asset('assets/backend/js/file_upload.js')); ?>"></script>

    <script type="text/javascript">
        $(document).ready(function() {
            $('#imageupload').submit(function(e) {
                if($('#video').val()) {
                    e.preventDefault();

                    $("#progress-bar-status-show").width('0%');

                    /* image traitement */
                    var file_details = document.getElementById("video").files[0];
                    var extension = file_details['name'].split(".");

                    var allowed_extension = ["webm", "mp4", "video/mp4", "'video/x-f4v", "video/webm", "video/x-flv"];
                    var check_for_valid_ext = allowed_extension.indexOf(extension[1]);

                    if (file_details['size'] > 268435456) {
                        alert('Veuillez télécharger un fichier inférieur à 128 MB');
                        return false;
                    } else if (check_for_valid_ext == -1) {
                        alert('Télécharger un fichier video valide !');
                        return false;

                    } else {
                        /* video traitement */
                        if($('#pdf').val()) {
                            var file_details2 = document.getElementById("pdf").files[0];
                            var extension2 = file_details2['name'].split(".");

                            var allowed_extension2 = ["PDF", "pdf", "doc", "docx","DOC", "DOCX", "jpg", "JPG","png", "PNG"];
                            var check_for_valid_ext2 = allowed_extension2.indexOf(extension2[1]);

                            if (file_details2['size'] > 268435456) {
                                alert('Veuillez télécharger un fichier inférieur à 128 MB');
                                return false;
                            } else if (check_for_valid_ext2 == -1) {
                                alert('Télécharger un fichier valide !');
                                return false;
                            }
                        }

                        $('#loader').show();
                        $('#progressbr-container').show();
                        $(this).ajaxSubmit({
                            target:   '#toshow',
                            beforeSubmit: function() {
                                $("#progress-bar-status-show").width('0%');
                            },
                            uploadProgress: function (event, position, total, percentComplete){
                                $("#progress-bar-status-show").width(percentComplete + '%');
                                $("#progress-bar-status-show").html('<div id="progress-percent">' + percentComplete +' %</div>');
                            },
                            success:function (){
                                $('#loader').hide();
                                $('#progressbr-container').hide();
                                window.location.href = "<?php echo e(url('coach-admin/formations-courses')); ?>";
                            },
                            resetForm: true

                        });
                        return false;

                    }
                }
            });
        });



    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make("layouts.coach-master", array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>