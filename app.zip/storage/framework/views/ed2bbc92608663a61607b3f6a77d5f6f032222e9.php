<?php $__env->startSection("content-main"); ?>

	<main>
		<section id="hero_in" class="coachs">
			<div class="wrapper">
				<div class="container">
					<h1 class="fadeInUp"><span></span>Liste des COACHS</h1>
				</div>
			</div>
		</section>
		<!--/hero_in-->
		<div class="filters_listing sticky_horizontal">
			<div class="container">
				<ul class="clearfix">
					<li>
						<div class="switch-field">
							<input type="radio" id="all" name="listing_filter" value="all" checked>
							<label for="all">Tout</label>
							<input type="radio" id="popular" name="listing_filter" value="popular">
							<label for="popular">Anciens</label>
							<input type="radio" id="latest" name="listing_filter" value="latest">
							<label for="latest">Récents</label>
						</div>
					</li>

					<li>
						<select name="orderby" class="selectbox">
							<option value="">--Tout--</option>
							<option value="">Promotion 2017</option>
							<option value="">Promotion 2018</option>
							<option value="">Promotion 2019</option>
							<option value="">Promotion 2020</option>
							<option value="">Promotion 2021</option>
						</select>
					</li>
				</ul>
			</div>
			<!-- /container -->
		</div>
		<!-- /filters -->

		<div class="container margin_60_35">
			<div class="row">
				<?php $__currentLoopData = $coachs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $coach): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
				<div class="col-xl-3 col-lg-4 col-md-6">
					<div class="box_grid wow">
						<figure class="figure-img-coach">
							<a href=""><img src="<?php if($coach->photo !=""): ?> <?php echo e(asset('assets/coachs/'.$coach->photo)); ?> <?php else: ?> <?php echo e(asset('assets/frontend/img/logoo.png')); ?> <?php endif; ?> " class="img-fluid style-img-coach" alt="<?php echo e($coach->nom.' '.$coach->prenom); ?> coach maroc"></a>

						</figure>
						<div class="wrapper text-center">
							<h3><?php echo e(strtoupper($coach->nom)); ?> <?php echo e(strtoupper($coach->prenom)); ?></h3>
							<p>
								<?php 
									$string = strip_tags(stripslashes( $coach->info_pers));
                                       if (strlen($string) > 200) {

                                           // truncate string
                                           $stringCut = substr($string, 0, 200);
                                           $endPoint = strrpos($stringCut, ' ');

                                           //if the string doesn't contain any space then it will cut without word basis.
                                           $string = $endPoint? substr($stringCut, 0, $endPoint) : substr($stringCut, 0);
                                           $string .= '...';
                                       }
								 ?>
								<?php echo e($string); ?>


							</p>
							<div class="rating"><i class="icon_star voted"></i><i class="icon_star voted"></i><i class="icon_star voted"></i><i class="icon_star voted"></i><i class="icon_star voted"></i> <small> </small></div>
						</div>




					</div>
				</div>
				<!-- /box_grid -->
				<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
			</div>
			<!-- /row -->

		</div>
		<!-- /container -->
		<div class="bg_color_1">
			<div class="container margin_60_35">
				<div class="row">
					<div class="col-md-4">
						<a href="#0" class="boxed_list">
							<i class="pe-7s-help2"></i>
							<h4>Besoin d'aide? Nous contacter</h4>
							<p>contacez nous pour plus d'informations. enovyer un email ou contacter nous par whatsapp 212629485433
							</p>
						</a>
					</div>
					<div class="col-md-4">
						<a href="#0" class="boxed_list">
							<i class="pe-7s-cash"></i>
							<h4>Paiement</h4>
							<p>Vous pouvez passer votre paiement par virement bancaire ou par verssement WafaCash ou Paypal.</p>
						</a>
					</div>
					<div class="col-md-4">
						<a href="#0" class="boxed_list">
							<i class="pe-7s-note2"></i>
							<h4>Qualité de formations</h4>
							<p>Nous proposant les plus excellent formations, présenté par les professionnels coachs au maroc</p>
						</a>
					</div>
				</div>
				<!-- /row -->
			</div>
			<!-- /container -->
		</div>
		<!-- /bg_color_1 -->
	</main>
	<!--/main-->
<?php $__env->stopSection(); ?>
<?php echo $__env->make("layouts.front-master", array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>