<?php $__env->startSection("content-main"); ?>
	<main>
		<section id="hero_in" class="general">
			<div class="wrapper">
				<div class="container">
					<h1 class="fadeInUp"><span></span>COACH Profil</h1>
				</div>
			</div>
		</section>
		<!--/hero_in-->
		<div class="container margin_60_35">
			<div class="row">
				<?php if( session()->has('success') ): ?>
					<div class="col-lg-12 col-md-12 col-12 alert alert-success">
						<?php echo e(session()->get('success')); ?>

					</div>
				<?php endif; ?>
			</div>

			<div class="row">
				<aside class="col-lg-3" id="sidebar">
					<div class="profile">
						<figure>
							<img src="<?php if($coach->image !=""): ?> <?php echo e(asset('assets/coachs/'.$coach->photo)); ?> <?php else: ?> <?php echo e(asset('assets/frontend/img/centre-mikdad.jpg')); ?> <?php endif; ?>" width="150" height="150" alt="Teacher" class="rounded-circle"></figure>
						<ul class="social_teacher">
							<li><a target="_blank" href="<?php echo e($coach->url_fb); ?>"><i class="icon-facebook"></i></a></li>
							<li><a target="_blank" href="<?php echo e($coach->url_inst); ?>"><i class="icon-instagram"></i></a></li>
							<li><a target="_blank" href="<?php echo e($coach->url_link); ?>"><i class="icon-linkedin"></i></a></li>
							<li><a target="_blank" href="<?php echo e($coach->url_tw); ?>"><i class="icon-twitter"></i></a></li>
<!--							<li><a href="#"><i class="icon-youtube"></i></a></li>-->
						</ul>
						<ul>
							<li>COACH <span class="float-right"><?php echo e($coach->nom); ?> <?php echo e($coach->prenom); ?></span> </li>
							<?php if( $coach->ville !="" ): ?><li>Ville  <span class="float-right"><?php echo e($coach->ville); ?></span></li><?php endif; ?>
							<li>Etudiants <span class="float-right">0</span></li>
							<li>Formations sur place<span class="float-right">0</span></li>
							<li>Formations en ligne<span class="float-right">0</span></li>
							<li>Formations en live<span class="float-right">0</span></li>
							<li>
								<button class="btn btn-success search-overlay-menu-btn col-md-12"> <i class="icon-direction-outline"></i> Envoyer message </button>
							</li>

							<?php if(Auth::check()): ?>

								<?php 
									$user = Auth::user();
								 ?>

								<?php if($user->role == 2): ?>
									<li>
										<form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" >
											<?php echo e(csrf_field()); ?>

											<button type="submit" class="btn btn-success col-md-12"><i class="fa fa-sign-out"></i>Déconnexion</button>
										</form>
									</li>
								<?php endif; ?>

							<?php endif; ?>

							<div class="search-overlay-menu">
								<span class="search-overlay-close"><span class="closebt"><i class="ti-close"></i></span></span>


								<form action="<?php echo e(url("envoyer-un-message")); ?>" role="search" id="searchform" method="post">

									<?php echo e(csrf_field()); ?>


									<div class="form-control">
										<label for="message"> Envoyer un message au Coach</label>
										<textarea class="form-control" required name="message" placeholder="Tappez votre message ici..." id="" cols="30" rows="3"></textarea>
										<input type="hidden" name="id" value="<?php echo e($coach->id); ?>">
										<input  class="btn btn-success mt-2" type="submit" value="Envoyer">
									</div>


								</form>
							</div>
						</ul>
					</div>
				</aside>
				<!--/aside -->

				<div class="col-lg-9">
					<div class="boc_teacher">
						<div class="alert alert-info">
							<p class="text-center"><b>Partager via</b></p>
							<ul class="social_teacher">
								<li class="bg-light"><a href="https://www.facebook.com/sharer/sharer.php?u=<?php echo e(url("coach/".$coach->id.'-'.$coach->nom.'-'.$coach->prenom)); ?>&t=je veux partager avec vous ce profil: <?php echo e(url("coach/".$coach->id.'-'.$coach->nom.'-'.$coach->prenom)); ?>" onclick="javascript:window.open(this.href, '', 'menubar=no,toolbar=no,resizable=yes,scrollbars=yes,height=300,width=600');return false;" target="_blank" title="Partager via Facebook"><i class="icon-facebook"></i></a></li>
								<li class="bg-light"><a href="https://wa.me/send?text=je veux partager avec vous ce contenu:  <?php echo e(url("coach/".$coach->id.'-'.$coach->nom.'-'.$coach->prenom)); ?>" data-action="share/whatsapp/share" onClick="javascript:window.open(this.href, '', 'menubar=no,toolbar=no,resizable=yes,scrollbars=yes,height=300,width=600');return false;" target="_blank" title="Partager via whatsapp"><i class="fa fa-whatsapp"></i></a></li>
								<li class="bg-light"><a href="https://www.linkedin.com/shareArticle?mini=true&url=<?php echo e(url("coach/".$coach->id.'-'.$coach->nom.'-'.$coach->prenom)); ?>&t=je veux partager avec vous ce contenu: <?php echo e(url("coach/".$coach->id.'-'.$coach->nom.'-'.$coach->prenom)); ?>" onclick="javascript:window.open(this.href, '', 'menubar=no,toolbar=no,resizable=yes,scrollbars=yes,height=300,width=600');return false;" target="_blank" title="Partager via Linkedin"><i class="icon-linkedin"></i></a></li>
								<li class="bg-light"><a href="https://twitter.com/share?url=<?php echo e(url("coach/".$coach->id.'-'.$coach->nom.'-'.$coach->prenom)); ?>&text=je veux partager avec vous ce contenu: <?php echo e(url("coach/".$coach->id.'-'.$coach->nom.'-'.$coach->prenom)); ?>"onclick="javascript:window.open(this.href, '', 'menubar=no,toolbar=no,resizable=yes,scrollbars=yes,height=300,width=600');return false;" target="_blank" title="Partager via Twitter"><i class="icon-twitter"></i></a></li>
							</ul>
						</div>
					</div>
					<div class="box_teacher">
						<div class="indent_title_in">

							<i class="pe-7s-user"></i>
							<h3>Profil : COACH <?php echo e($coach->prenom); ?> <?php echo e($coach->nom); ?></h3>
							<p><?php echo e($coach->specialities); ?></p>
						</div>
						<div class="wrapper_indent">
							<p><?php echo e($coach->info_pers); ?></p>

							<?php if( $coach->bio !=""): ?>
								<h5>Biographie</h5>
								<p><?php echo e(str_replace("&nbsp;", " ", strip_tags($coach->bio))); ?></p>
							<?php endif; ?>

							<?php if($coach->diplomes !=""): ?>
							<h5>Diplômes</h5>
							<p><?php echo e(str_replace("&nbsp;", " ", strip_tags($coach->diplomes))); ?></p>
							<?php endif; ?>
						</div>
						<!--wrapper_indent -->
						<hr class="styled_2">
						<div class="indent_title_in">
							<i class="pe-7s-display1"></i>
							<h3>Formations & Consultations</h3>
							<p>mes formations et mes consultations peut êtres sur place, en ligne ou live.</p>
						</div>
						<div class="wrapper_indent">
							<div class="container margin_60_35">
								<div class="row">
									<div class="col-xl-4 col-lg-4 col-md-12">
										<div class="box_grid wow">
											<figure>
												<a href="<?php echo e(url('coach/'.$coach->id.'-'.$coach->prenom.'-'.$coach->nom.'/formations')); ?>"><img src="<?php echo e(asset('assets/frontend')); ?>/img/formation.jpg" class="img-fluid" alt="">

													<div class="preview2"><span>Formations</span></div>
												</a>
											</figure>

										</div>
									</div>
									<!-- /box_grid -->
									<div class="col-xl-4 col-lg-4 col-md-12">
										<div class="box_grid wow">
											<figure>
												<a href="#"><img src="<?php echo e(asset('assets/frontend')); ?>/img/consultation.jpg" class="img-fluid" alt="">
												<div class="preview2"><span>Consultations</span></div>
												</a>
											</figure>

										</div>
									</div>
									<!-- /box_grid -->
									<div class="col-xl-4 col-lg-4 col-md-12">
										<div class="box_grid wow">
											<figure>
												<a href="<?php echo e(url('coach/'. $coach->id.'-'. $coach->prenom.'-'.$coach->nom.'/articles')); ?>"><img src="<?php echo e(asset('assets/frontend')); ?>/img/read-article.jpg" class="img-fluid" alt="">
													<div class="preview2"><span>Articles</span></div>
												</a>
											</figure>

										</div>
									</div>
								</div>
								<!-- /row -->
							</div>
						</div>
						<!--wrapper_indent -->
						<?php if(count($galeries_images)> 0 || count($galeries_videos)> 0): ?>
						<hr class="styled_2">
						<div class="indent_title_in">
							<i class="pe-7s-display2"></i>
							<h3>Galerie</h3>
							<p>Bienvenu sur ma galerie de photos & vidéos </p>
						</div>
						<?php endif; ?>
						<div class="wrapper_indent">
							<?php if(count($galeries_images)> 0): ?>
								<div class="container margin_60_35">
								<div class="main_title_2">
									<span><em></em></span>
									<h2>Voiçi quelques photos de ma carrière</h2>
									<p>j'aimerais bien partager avec vous ces moments.</p>
								</div>
								<div class="grid">
									<ul class="magnific-gallery">
										<?php $__currentLoopData = $galeries_images; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $obj): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
										<li>
											<figure>
												<img src="<?php echo e($obj->lien); ?>" alt="<?php if($obj->titre !=""): ?> <?php echo e($obj->titre); ?> Centre Mikdad <?php else: ?> Centre Mikdad galerie de photos <?php endif; ?> ">
												<figcaption>
													<div class="caption-content">
														<a href="<?php echo e($obj->lien); ?>" title="<?php if($obj->titre !=""): ?> <?php echo e($obj->titre); ?> Centre Mikdad <?php else: ?> Centre Mikdad galerie de photos <?php endif; ?> " data-effect="mfp-zoom-in">
															<i class="pe-7s-albums"></i>
															<p>Aperçu</p>
														</a>
													</div>
												</figcaption>
											</figure>
										</li>
										<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
									</ul>
								</div>
								<!-- /grid gallery -->
							</div>
							<?php endif; ?>
							<!-- /container -->
							<?php if(count($galeries_videos)> 0): ?>
								<div class="bg_color_1">
									<div class="container margin_60_35">
										<div class="main_title_2">
											<span><em></em></span>
											<h2>Voiçi quelques vidéos de ma carrière</h2>
											<p>j'aimerais bien partager avec vous ces moments.</p>
										</div>
										<div class="grid">
											<ul class="magnific-gallery">

												<?php $__currentLoopData = $galeries_videos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $video): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
													<li>
														<figure>
															<img src="<?php echo e(asset("assets/frontend/img/apercu-video.jpg")); ?>" alt="<?php if($video->titre !=""): ?> <?php echo e($video->titre); ?> Centre Mikdad <?php else: ?> Centre Mikdad galerie de vidéos <?php endif; ?> ">
															<figcaption>
																<div class="caption-content">
																	<a href="<?php echo e($video->lien); ?>" class="video" title="<?php if($video->titre !=""): ?> <?php echo e($video->titre); ?> Centre Mikdad <?php else: ?> Centre Mikdad galerie de vidéos <?php endif; ?> ">
																		<i class="pe-7s-film"></i>
																		<p>Aperçu</p>
																	</a>
																</div>
															</figcaption>
														</figure>
													</li>
												<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
											</ul>
										</div>
										<!-- /grid -->
									</div>
									<!-- /container -->
								</div>
								<!-- /bg_color_1 -->
							<?php endif; ?>
						</div>
					</div>
				</div>
				<!-- /col -->
			</div>
			<!-- /row -->
		</div>
		<!-- /container -->

	</main>
<?php $__env->stopSection(); ?>
<!-- /main -->


<?php echo $__env->make("layouts.front-master", array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>