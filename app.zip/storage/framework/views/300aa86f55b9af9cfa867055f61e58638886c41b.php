<?php $__env->startSection("content"); ?>
    <div class="content-wrapper">
        <div class="container-fluid">
            <?php if( session()->has('success') ): ?>
            <div class="alert alert-success">
                <?php echo e(session()->get('success')); ?>

            </div>
            <?php endif; ?>
            <!-- Breadcrumbs-->
            <ol class="breadcrumb">
                <li class="breadcrumb-item">
                    <a href="<?php echo e(url("coach-admin")); ?>">Dashboard</a>
                </li>
                <li class="breadcrumb-item active">Gérer les bénéficiers</li>
            </ol>
            <!-- Example DataTables Card-->
            <div class="mb-3">

            </div>
            <div class="card mb-3">

                <div class="card-header">
                    <i class="fa fa-table"></i> Liste des coaches & bénéficiers</div>
                <div class="card-body">
                    <div class="table-responsive">
                        <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                            <thead>
                            <tr>
                                <th>N°</th>
                                <th>Nom Complet</th>
                                <th>Type d'utilisateur</th>

                                <th>Action</th>
                            </tr>
                            </thead>
                            <tbody>

                            <?php 
                                 $cmpt = 1;

                             ?>

                            <?php $__currentLoopData = $userslist; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $std): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                            <tr>
                                <td style="width: 5%;">#<?php echo e($cmpt); ?></td>
                                <td style="width: 20%;">







                                        <?php echo e(strtoupper($std->nom).' '.strtoupper($std->prenom)); ?>









                                </td>
                                <td style="width: 15%;">

                                       Bénéficier





                                </td>







                                <td style="width: 15%;">
                                    <button data-id="<?php echo e($std->id); ?>" type="submit" class="delete btn btn-danger btn-sm col-5 mb-1" data-toggle="modal"
                                            data-target="#deleteModal" ><i class="fa fa-trash"></i> Supprimer</button>

                                    <a href="<?php echo e(url("coach-admin/students-permessions/".$std->user_id)); ?>" class="btn btn-primary btn-sm col-6 mb-1"><i class="fa fa-lock"></i> Permissions</a>
                                </td>
                            </tr>
                            <?php 

                                $cmpt++;

                             ?>

                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>

                        <!-- Delete Warning Modal -->
                        <div class="modal modal-danger fade" id="deleteModal" tabindex="-1" role="dialog" aria-labelledby="Delete" aria-hidden="true">
                            <div class="modal-dialog" role="document">
                                <div class="modal-content">
                                    <div class="modal-header">
                                        <h5 class="modal-title" id="exampleModalLabel">Supprimer Le Bénéficiaire</h5>
                                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                            <span aria-hidden="true">&times;</span>
                                        </button>
                                    </div>
                                    <div class="modal-body">
                                        <form id="confirmed" action="" method="post">

                                            <?php echo e(csrf_field()); ?>



                                            <input type="hidden" id="id" name="id">
                                            <h5 class="text-center">Êtes-vous sûr de vouloir supprimer ce Bénéficiaire ?</h5>
                                            <div class="modal-footer">
                                                <button type="button" class="btn btn-sm btn-secondary" data-dismiss="modal">Annuler</button>
                                                <button type="submit" class="btn btn-sm btn-danger">Supprimer</button>
                                            </div>
                                        </form>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <!-- End Delete Modal -->
                    </div>
                </div>
            </div>
            <!-- /tables-->
        </div>
        <!-- /container-fluid-->
    </div>
    <!-- /container-wrapper-->



<?php $__env->stopSection(); ?>
<script src="<?php echo e(asset("assets/frontend")); ?>/js/jquery-2.2.4.min.js"></script>

<script>

    $(document).on('click','.delete',function(){

        let id = $(this).attr('data-id');

        $('#id').val(id);

        $('#confirmed').attr('action' , "<?php echo e(url('coach-admin/student-delete')); ?>" +"/"+id );

    });
</script>
<!-- /container-wrapper-->
<?php echo $__env->make("layouts.coach-master", array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>