<?php $__env->startSection("content"); ?>

    <div class="content-wrapper">
    <div class="container-fluid">
		<?php if( session()->has('success') ): ?>
			<div class="alert alert-success">
				<?php echo e(session()->get('success')); ?>

			</div>
		<?php endif; ?>
      <!-- Breadcrumbs-->
      <ol class="breadcrumb">
        <li class="breadcrumb-item">
          <a href="#">Dashboard</a>
        </li>
        <li class="breadcrumb-item active">Demandes de formations</li>
      </ol>
		<div class="box_general">
			<div class="header_box">
				<h2 class="d-inline-block">Les demandes</h2>
				<div class="filter">
					<select name="orderby" class="selectbox">
						<option value="Any status">--Tout--</option>
						<option value="Approved">Validé</option>
						<option value="Pending">En attente</option>
						<option value="Cancelled">Annulé</option>
					</select>
				</div>
			</div>
			<div class="list_general">
				<ul>
					<?php $__currentLoopData = $demandes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $obj): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
						<?php  $user = getUserById( $obj->user_id);
							if ($user->role == 1) $benificier = geStudentByUSER_Id($user->id);
							elseif ($user->role == 2) $benificier = getCoachByUSER_Id($user->id);
						 ?>
					<li>
						<figure><img src=<?php if( $benificier->photo !="" && $benificier->photo !=null): ?> <?php if($user->role == 2): ?> <?php echo e(asset('assets/coachs/'.$benificier->photo)); ?> <?php elseif($user->role == 1): ?> <?php echo e(asset('assets/students/'.$benificier->photo)); ?>	<?php endif; ?> <?php else: ?> <?php echo e(asset('assets/frontend/img/logo_found.JPG')); ?> <?php endif; ?> alt=""></figure>

						<ul class="course_list">
							<li><strong>Nom Complet : </strong> <?php echo e($benificier->nom); ?> <?php echo e($benificier->prenom); ?></li>
							<li><strong>Téléphone : </strong>  <?php echo e($benificier->tel); ?> </li>
							<li><strong>Date de demande : </strong>  <?php echo e($obj->created_at); ?> </li>
							<li><strong>Date de paiement : </strong> <?php if($obj->validation == 0  ||  $obj->validation == -1): ?>  <?php echo e("--/--/--"); ?> <?php elseif($obj->validation >= 1): ?> <?php echo e($obj->date_validation); ?> <?php endif; ?></li>
							<li><strong>La formation demander : </strong> <?php echo e(getNameFormationById($obj->formation_id)); ?></li>
							<li><strong>Paiement : </strong> <?php if( $obj->validation == 0 ||  $obj->validation == -1): ?>  <?php echo e("Impayé"); ?> <?php elseif($obj->validation == 1 || $obj->validation == 2): ?> <?php echo e("Payé"); ?>

								<a class="mr-2 btn btn-success btn-sm" href="<?php echo e(asset("assets/recus/".$obj->recu )); ?>" download="download"><i class="fa fa-download"></i> Télécharger le reçu</a> <?php endif; ?>
							</li>
							<li> <?php if( $obj->validation == -1): ?><strong>Remarque : </strong> <?php echo e($obj->remarque); ?>  <?php endif; ?></li>
                            <ul class="buttons">
								<li><button data-id="<?php echo e($obj->id); ?>" type="submit" data-toggle="modal"
											data-target="#validerModal" class=" btn_1 gray approve"><i class="fa fa-fw fa-check-circle-o"></i> Valider</button></li>

                                <li><button data-id="<?php echo e($obj->id); ?>" type="submit" data-toggle="modal"
											data-target="#refuserModal" class="btn_1 gray delete"><i class="fa fa-fw fa-times-circle-o"></i> Refuser</button></li>
                            </ul>
						</ul>
					</li>
					<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
					
				</ul>
			</div>
		</div>
		<!-- /box_general-->
		<nav aria-label="...">
			<ul class="pagination pagination-sm add_bottom_30">
				<li class="page-item disabled">
					<a class="page-link" href="#" tabindex="-1">Previous</a>
				</li>
				<li class="page-item"><a class="page-link" href="#">1</a></li>
				<li class="page-item"><a class="page-link" href="#">2</a></li>
				<li class="page-item"><a class="page-link" href="#">3</a></li>
				<li class="page-item">
					<a class="page-link" href="#">Next</a>
				</li>
			</ul>
		</nav>
		<!-- /pagination-->
	  </div>
	  <!-- /container-fluid-->
   	</div>
    <!-- /container-wrapper-->
	<!-- valider Warning Modal -->
	<div class="modal modal-danger fade" id="validerModal" tabindex="-1" role="dialog" aria-labelledby="Delete" aria-hidden="true">
		<div class="modal-dialog" role="document">
			<div class="modal-content">
				<div class="modal-header">
					<h5 class="modal-title" id="exampleModalLabel">Valider La demande</h5>
					<button type="button" class="close" data-dismiss="modal" aria-label="Close">
						<span aria-hidden="true">&times;</span>
					</button>
				</div>
				<div class="modal-body">
					<form id="confirmed" action="" method="post">

						<?php echo e(csrf_field()); ?>


						<input type="hidden" id="iddemande" name="iddemande">
						<h5 class="text-center">Êtes-vous sûr de vouloir valider cette demande ?</h5>
						<div class="modal-footer">
							<button type="button" class="btn btn-sm btn-secondary" data-dismiss="modal">Annuler</button>
							<button type="submit" class="btn btn-sm btn-success">Valider</button>
						</div>
					</form>
				</div>
			</div>
		</div>
	</div>
	<!-- End valider Modal -->

	<!-- refuser Warning Modal -->
	<div class="modal modal-danger fade" id="refuserModal" tabindex="-1" role="dialog" aria-labelledby="Delete" aria-hidden="true">
		<div class="modal-dialog" role="document">
			<div class="modal-content">
				<div class="modal-header">
					<h5 class="modal-title" id="exampleModalLabel2">Valider La demande</h5>
					<button type="button" class="close" data-dismiss="modal" aria-label="Close">
						<span aria-hidden="true">&times;</span>
					</button>
				</div>
				<div class="modal-body">
					<form id="confirmed_r" action="" method="post">

						<?php echo e(csrf_field()); ?>


						<input type="hidden" id="iddemande_r" name="iddemande_r">
						<h5 class="text-center">Êtes-vous sûr de vouloir refuser cette demande ?</h5>
						<hr>
						<div class="form-group">
							<label for="remarque" class="form-control text-center"> Donner une justification</label>
							<textarea placeholder="Tappez ici votre remarque..." name="remarque" class="form-control" id="remarque" cols="30" rows="3"></textarea>
						</div>
						<div class="modal-footer">
							<button type="button" class="btn btn-sm btn-secondary" data-dismiss="modal">Annuler</button>
							<button type="submit" class="btn btn-sm btn-danger">Refuser</button>
						</div>
					</form>
				</div>
			</div>
		</div>
	</div>
	<!-- End refuser Modal -->

<?php $__env->stopSection(); ?>
<script src="<?php echo e(asset("assets/frontend")); ?>/js/jquery-2.2.4.min.js"></script>

<script>

	$(document).on('click','.approve',function(){

		let id = $(this).attr('data-id');

		$('#iddemande').val(id);

		$('#confirmed').attr('action' , "<?php echo e(url('coach-admin/valider-demande')); ?>" +"/"+id );

	});
</script>

<script>

	$(document).on('click','.delete',function(){

		let id = $(this).attr('data-id');

		$('#iddemande_r').val(id);

		$('#confirmed_r').attr('action' , "<?php echo e(url('coach-admin/refuser-demande')); ?>" +"/"+id );

	});
</script>
<!-- /container-wrapper-->
<?php echo $__env->make("layouts.coach-master", array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>