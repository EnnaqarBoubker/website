<?php $__env->startSection("content-main"); ?>
	<main>
		<section id="hero_in" class="general">
			<div class="wrapper">
				<div class="container">
					<h1 class="fadeInUp"><span></span>Mon Profil</h1>
				</div>
			</div>
		</section>
		<!--/hero_in-->
		<div class="container margin_60_35">
			<div class="row">
				<aside class="col-lg-3" id="sidebar">
					<div class="profile">
						<figure><img src="<?php echo e(asset( 'assets/frontend/img/logoo.png')); ?>" width="150" height="150" alt="Centre Mikdad" class="rounded-circle"></figure>
						<ul>
							<li>Nom <span class="float-right"><?php echo e($student->nom); ?> <?php echo e($student->prenom); ?></span> </li>
							<?php if( $student->ville !=""): ?><li>Ville <span class="float-right"><?php echo e($student->ville); ?></span></li><?php endif; ?>
							<li>Notifications <span class="float-right">(0)</span></li>
							<li>Messages<span class="float-right">(0)</span></li>
							<li>Nbr Formations<span class="float-right">(<?php echo e(count($formations)); ?>)</span></li>
							<li>Nbr Consultations<span class="float-right">(0)</span></li>
							<li>
							<li>

                                <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" >
                                    <?php echo e(csrf_field()); ?>

                                    <button type="submit" class="btn btn-success search-overlay-menu-btn"><i class="fa fa-sign-out"></i>Déconnexion</button>
                                </form>
                                <span class="float-right"> </span></li>
						</ul>
					</div>
				</aside>
				<!--/aside -->

				<div class="col-lg-9">
					<div class="box_teacher">
						<div class="indent_title_in">
							<i class="pe-7s-user"></i>
							<h3>Profil : <?php echo e($student->prenom); ?> <?php echo e($student->nom); ?></h3>
							<p>

							</p>
						</div>
						<div class="wrapper_indent">

						</div>
						<!--wrapper_indent -->
						<hr class="styled_2">
						<div class="indent_title_in">
							<i class="pe-7s-display1"></i>
							<h3>Formations</h3>
							<p>Votre formations en ligne.</p>
						</div>
						<div class="wrapper_indent">
							<div class="container margin_35">
								<div class="row">
									<?php $__currentLoopData = $formations; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $obj): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

										<div class="col-xl-6 col-lg-6 col-md-6 col-12">
											<div class="box_grid wow">
												<figure>
													<a href="<?php echo e(url('details-formation/'.$obj->id.'-'.$obj->titre)); ?>"><img src="<?php if($obj->image !=""): ?> <?php echo e(asset('assets/formations/'.$obj->image)); ?> <?php else: ?> <?php echo e(asset('assets/frontend/img/centre-mikdad.jpg')); ?> <?php endif; ?> " class="img-fluid" alt="Centre Mikdad <?php echo e($obj->titre); ?>"></a>
													<div class="price">
														<?php if($obj->new_prix > 0): ?>
															<del> <?php echo e($obj->prix); ?> Dhs</del>  <?php echo e($obj->new_prix); ?> Dhs
														<?php else: ?>
															<?php echo e($obj->prix); ?> Dhs
														<?php endif; ?>
													</div>
													<div class="preview"><a href="<?php echo e(url('details-formation/'.$obj->id.'-'.$obj->titre)); ?>"><span>Afficher les détails</span></a></div>
												</figure>
												<div class="wrapper">
													<small>Categorie: <?php echo e(getNameCategorieById( $obj->categorie_id )); ?> </small>
													<h3><?php echo e($obj->titre); ?></h3>
													<p>
														<?php 
															$desc =  str_replace("&nbsp;", " ", strip_tags($obj->description));
                                                               if (strlen($desc) > 90) {

                                                                   // truncate string
                                                                   $descCut = substr($desc, 0, 90);
                                                                   $endPoint = strrpos($descCut, ' ');

                                                                   //if the string doesn't contain any space then it will cut without word basis.
                                                                   $desc = $endPoint? substr($descCut, 0, $endPoint) : substr($descCut, 0);
                                                                   $desc .= '...';
                                                               }
														 ?>
														<?php echo e($desc); ?>

													</p>
												</div>
												<ul>
													<li><i class="fa fa-download"></i></li>
													<li><a href="<?php echo e(url( 'details-formation/'.$obj->id.'-'.$obj->titre )); ?>">Afficher les détails</a></li>
												</ul>
											</div>
										</div>
										<!-- /box_grid -->



									<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
								</div>
								<!-- /row -->
							</div>
						</div>
						<!--wrapper_indent -->

					</div>
				</div>
				<!-- /col -->
			</div>
			<!-- /row -->
		</div>
		<!-- /container -->
	</main>
<?php $__env->stopSection(); ?>
<!-- /main -->


<?php echo $__env->make("layouts.front-master", array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>