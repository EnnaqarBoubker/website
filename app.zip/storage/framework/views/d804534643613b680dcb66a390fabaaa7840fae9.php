

<?php $__env->startSection("addheaderscript"); ?>

    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('assets/backend/css/form-upload.css')); ?>">

<?php $__env->stopSection(); ?>

<?php $__env->startSection("content"); ?>

    <!-- /Navigation-->
    <div class="content-wrapper">
        <div class="container-fluid">

            <!-- Breadcrumbs-->
            <ol class="breadcrumb">
                <li class="breadcrumb-item">
                    <a href=" <?php echo e(url('coach-admin')); ?> ">Dashboard</a>
                </li>
                <li class="breadcrumb-item active">Bénéficiers : Permissions</li>
            </ol>
            <form method="post" action=" <?php echo e(url('coach-admin/givepermissions')); ?> " enctype="multipart/form-data" >
                <?php echo e(csrf_field()); ?>

            <div class="box_general padding_bottom">

                <div class="row">
                    <div class="col-md-12 text-center">
                        <?php if($user->role == 1): ?>
                                <?php  $personne = geStudentByUSER_Id($user->id)  ?>
                            <?php else: ?>
                                <?php  $personne = getCoachByUSER_Id($user->id)  ?>
                        <?php endif; ?>

                        <h5>Choisissez le(s) formation(s) sur lesquels vous souhaitez affecter pour : <?php echo e($personne->nom.' '.$personne->prenom); ?></h5>

                    </div>
                    <hr>
                    <input type="hidden" name="user_id" value="<?php echo e($user->id); ?>">
                    <div class="col-md-12">
                        <div class="row">
                        <?php $__currentLoopData = $formations; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $obj): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                            <div class="col-md-4">
                                <div class="custom-control custom-checkbox">
                                    <input style="width: 22px; height: 25px;" <?php if(test_formation_user_ByIduser_and_Idformation( $user->id, $obj->id)): ?> checked  <?php endif; ?> type="checkbox" id="customCheckbox<?php echo e($obj->id); ?>" name="formations_ids[]" value="<?php echo e($obj->id); ?>">
                                    <label for="customCheckbox<?php echo e($obj->id); ?>" class="custom-control-label ml-2"> Formation : <?php echo e($obj->titre); ?> </label>
                                </div>
                            </div>

                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
                    </div>
                </div>
                <!-- /row-->
                <div class="row">
                    <p class="col-md-12 text-center"><input type="submit" class="btn_1 medium" value="Donner l'accès"></p>

                </div>
            </div>
            <!-- /box_general-->
        </form>
        </div>
        <!-- /.container-fluid-->
    </div>
    <!-- /.container-wrapper-->
<?php $__env->stopSection(); ?>

<?php echo $__env->make("layouts.coach-master", array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>