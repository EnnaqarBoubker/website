<?php $__env->startSection("content"); ?>
    <div class="content-wrapper">
        <div class="container-fluid">
            <?php if( session()->has('success') ): ?>
            <div class="alert alert-success">
                <?php echo e(session()->get('success')); ?>

            </div>
            <?php endif; ?>
            <!-- Breadcrumbs-->
            <ol class="breadcrumb">
                <li class="breadcrumb-item">
                    <a href="<?php echo e(url("admin")); ?>">Dashboard</a>
                </li>
                <li class="breadcrumb-item active">Gérer les catégories</li>
            </ol>
            <!-- Example DataTables Card-->
            <div class="mb-3">
                <a href="<?php echo e(url("admin/categories/ajouter")); ?>" class="btn btn-primary"><i class="fa fa-plus-circle"></i> Ajouter une catégorie</a>
            </div>
            <div class="card mb-3">

                <div class="card-header">
                    <i class="fa fa-table"></i> Liste des catégories</div>
                <div class="card-body">
                    <div class="table-responsive">
                        <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                            <thead>
                            <tr>
                                <th>N°</th>
                                <th>Nom du catégorie</th>
                                <th>Statut</th>
                                <th>Date de création</th>
                                <th>Action</th>
                            </tr>
                            </thead>
                            <tbody>

                            <?php 
                                $count = 1
                             ?>

                            <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $obj): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td style="width: 5%;">#<?php echo e($count++); ?></td>
                                <td style="width: 30%;"><?php echo e($obj->nom); ?></td>

                                <td style="width: 20%;">
                                    <?php if($obj->status == 1): ?>
                                    <i class="read">Afficher</i>
                                    <?php else: ?>
                                        <i class="unread">Non Afficher</i>
                                    <?php endif; ?>
                                </td>
                                <td style="width: 30%;"><?php echo e($obj->created_at); ?></td>
                                <td style="width: 15%;">
                                    <a href="<?php echo e(url("admin/categories/".$obj->id."/edit")); ?>" class="btn btn-primary btn-sm col-12 mb-1"><i class="fa fa-edit"></i> Modifier</a>
                                    <form action="<?php echo e(url("admin/categories/".$obj->id)); ?>" method="post">

                                        <?php echo e(csrf_field()); ?>

                                        <?php echo e(method_field("DELETE")); ?>


                                        <button type="submit" class="btn btn-danger btn-sm col-12 mb-1" ><i class="fa fa-trash"></i> Supprimer</button>
                                    </form>
                                </td>
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
            <!-- /tables-->
        </div>
        <!-- /container-fluid-->
    </div>
    <!-- /container-wrapper-->
<?php $__env->stopSection(); ?>
<?php echo $__env->make("layouts.admin-master", array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>